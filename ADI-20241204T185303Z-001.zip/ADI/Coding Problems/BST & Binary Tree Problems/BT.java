// Create Binary Tree

import java.util.*;

class Node {
	int data;
	Node left, right;
public Node (int data) {
	this.data = data;} }

class BinaryTreeCreate {
  static Scanner sc = new Scanner(System.in);
  public static void main (String [] args) {

	Node root = createTree();  }

static Node createTree() {
	Node root = null;
System.out.println("Enter Data (-1 for null)");
	int data = sc.nextInt(();
	if (data==-1) return null;
	root = new Node(data);
	System.out.println("Enter left child for "+data);
	root.left= createTree();
	System.out.println("Enter right child for "+data);
	root.right= createTree();
	return root;
}
}

