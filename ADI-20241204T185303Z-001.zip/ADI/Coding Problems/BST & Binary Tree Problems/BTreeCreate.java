// Create BTree

import java.util.Scanner;

class Node {
  int data;
  Node left,right;

public Node(int data) {
	this.data=data;}
}

class BTreeCreate {
  static Scanner sc= new Scanner(System.in);
  public static void main(String [] args){
	Node root= createTree();
	System.out.println("In-order Traversal");
	inOrder(root);
	System.out.println("\n Pre-order Traversal");
	preOrder(root);
	System.out.println("\n Post-order Traversal");
	postOrder(root);
}
  static Node createTree() {
	Node root=null;

	System.out.println("Enter the data(-1 for null)");
	int data= sc.nextInt();
	if (data==-1) return null;
       
	root= new Node(data);
        System.out.println("Enter left child for "+data);
	root.left= createTree();
	System.out.println("Enter right child for "+data);
	root.right= createTree();

	return root;
}

static void inOrder(Node root){
	if (root==null) return;
	inOrder(root.left);
	System.out.print(root.data+" ");
	inOrder(root.right);
	}

static void preOrder(Node root){
	if (root==null) return;
	System.out.print(root.data+" ");
	preOrder(root.left);
	preOrder(root.right);
	}

static void postOrder(Node root){
	if (root==null) return;
	postOrder(root.left);
	postOrder(root.right);
	System.out.print(root.data+" ");
	}


}