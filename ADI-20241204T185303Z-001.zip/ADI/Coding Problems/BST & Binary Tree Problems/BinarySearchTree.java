// Binary Search Tree Insert, Search, Deelte operations in Java

class BinarySearchTree {
  class Node {
    int key;
    Node left, right;

    public Node(int item) {
      key = item;
      left = right = null;
    }
  }

  Node root;

  BinarySearchTree() {
    root = null;
  }

  void insert(int key) {
    root = insertKey(root, key);
  }

  // Insert key in the tree
  Node insertKey(Node root, int key) {
    // Return a new node if the tree is empty
    if (root == null) {
      root = new Node(key);
      return root;
    }

    // Traverse to the right place and insert the node
    if (key < root.key)
      root.left = insertKey(root.left, key);
    else if (key > root.key)
      root.right = insertKey(root.right, key);

    return root;
  }

  void inorder() {
    inorderRec(root);
  }

  void preorder() {
    preorderRec(root);
  }

  void postorder() {
    postorderRec(root);
  }

  // Inorder Traversal
  void inorderRec(Node root) {
    if (root != null) {
      inorderRec(root.left);
      System.out.print(root.key + " -> ");
      inorderRec(root.right);
    }
  }

// Preorder Traversal
  void preorderRec(Node root) {
    if (root != null) {
      System.out.print(root.key + " -> ");
      preorderRec(root.left);
      preorderRec(root.right);
    }
  }

// Postorder Traversal
  void postorderRec(Node root) {
    if (root != null) {
      postorderRec(root.left);
      postorderRec(root.right);
      System.out.print(root.key + " -> ");
    }
  }

  void deleteKey(int key) {
    root = deleteRec(root, key);
  }
  Node deleteRec(Node root, int key) {
    // Return if the tree is empty
    if (root == null)
      return root;

    // Find the node to be deleted
    if (key < root.key)
      root.left = deleteRec(root.left, key);
    else if (key > root.key)
      root.right = deleteRec(root.right, key);
    else {
      // If the node is with only one child or no child
      if (root.left == null)
        return root.right;
      else if (root.right == null)
        return root.left;

      // If the node has two children
      // Place the inorder successor in position of the node to be deleted
      root.key = minValue(root.right);

      // Delete the inorder successor
      root.right = deleteRec(root.right, root.key);
    }

    return root;
  }

  // Find the inorder successor
  int minValue(Node root) {
    int minv = root.key;
    while (root.left != null) {
      minv = root.left.key;
      root = root.left;
    }
    System.out.println("Inorder Successor :"+minv);
    return minv;
  }   

  // Driver Program to test above functions
  public static void main(String[] args) {
    BinarySearchTree tree = new BinarySearchTree();

    tree.insert(8);
    tree.insert(3);
    tree.insert(1);
    tree.insert(6);
    tree.insert(7);
    tree.insert(10);
tree.insert(11);
    tree.insert(14);
    tree.insert(4);
    tree.insert(3);
System.out.println();
    System.out.print("Inorder traversal: ");
    tree.inorder();
System.out.println();
    System.out.print("Preorder traversal: ");
    tree.preorder();
System.out.println();
    System.out.print("Postorder traversal: ");
    tree.postorder();
System.out.println();

    System.out.println("\n\nAfter deleting 8");
    tree.deleteKey(8);
    System.out.print("Inorder traversal: ");
    tree.inorder();
  }
}