// Find the kth smallest element in the binary search tree

import java.util.Scanner;

class TreeNode {
    int val;
    TreeNode left, right;

    TreeNode(int item) {
        val = item;
        left = right = null;
    }
}

class Solution {
    private int count = 0;
    private int result = 0;

    public int kthSmallest(TreeNode root, int k) {
        inorderTraversal(root, k);
        return result;
    }

    private void inorderTraversal(TreeNode node, int k) {
        if (node == null || count >= k) {
            return;
        }

        inorderTraversal(node.left, k);
        
        count++;
        if (count == k) {
            result = node.val;
            return;
        }

        inorderTraversal(node.right, k);
    }
}

class BinarySearchTree {
    TreeNode root;

    // Insert a new node in the BST
    public void insert(int key) {
        root = insertRec(root, key);
    }

    // Utility function for insertion
    private TreeNode insertRec(TreeNode root, int key) {
        if (root == null) {
            root = new TreeNode(key);
            return root;
        }
        if (key < root.val) {
            root.left = insertRec(root.left, key);
        } else if (key > root.val) {
            root.right = insertRec(root.right, key);
        }
        return root;
    }
}

public class KSmallestBinarySearchTree {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BinarySearchTree bst = new BinarySearchTree();

        // Input for the BST
        System.out.println("Enter values to insert into the BST (comma separated):");
        String[] values = scanner.nextLine().split(",");
        for (String value : values) {
            bst.insert(Integer.parseInt(value.trim()));
        }

        // Input for kth smallest element
        System.out.println("Enter the value of k to find the kth smallest element:");
        int k = scanner.nextInt();

        // Find and print the kth smallest element
        Solution solution = new Solution();
        int result = solution.kthSmallest(bst.root, k);
        System.out.println("The " + k + "th smallest element is: " + result);
        
        scanner.close();
    }
}
