// Kth Largest Element in BST

import java.util.Scanner;

class TreeNode {
    int value;
    TreeNode left;
    TreeNode right;

    TreeNode(int value) {
        this.value = value;
        left = null;
        right = null;
    }
}

class BST {
    private TreeNode root;
    private int count; // Counter for the number of nodes visited
    private Integer kthGreatest; // Variable to store the k-th greatest value

    public void insert(int value) {
        root = insertRec(root, value);
    }

    private TreeNode insertRec(TreeNode root, int value) {
        if (root == null) {
            return new TreeNode(value);
        }
        if (value < root.value) {
            root.left = insertRec(root.left, value);
        } else {
            root.right = insertRec(root.right, value);
        }
        return root;
    }

    public Integer findKthGreatest(int k) {
        count = 0;
        kthGreatest = null;
        findKthGreatestRec(root, k);
        return kthGreatest;
    }

    private void findKthGreatestRec(TreeNode node, int k) {
        if (node == null || kthGreatest != null) {
            return; // Stop if we found the k-th greatest or reached a leaf
        }

        // Traverse the right subtree first (for greatest elements)
        findKthGreatestRec(node.right, k);
        
        // Visit this node
        count++;
        if (count == k) {
            kthGreatest = node.value; // Found the k-th greatest
            return;
        }

        // Traverse the left subtree
        findKthGreatestRec(node.left, k);
    }
}

public class KthGreatestBST {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BST bst = new BST();

        System.out.println("Enter numbers to insert into the BST (type 'exit' to stop):");
        while (scanner.hasNext()) {
            if (scanner.hasNextInt()) {
                int value = scanner.nextInt();
                bst.insert(value);
            } else if (scanner.next().equalsIgnoreCase("exit")) {
                break;
            } else {
                System.out.println("Invalid input. Please enter integers or 'exit' to stop.");
                scanner.next(); // Consume the invalid input
            }
        }

        System.out.print("Enter the value of k to find the k-th greatest element: ");
        int k = scanner.nextInt();
        Integer result = bst.findKthGreatest(k);

        if (result != null) {
            System.out.println("The " + k + "-th greatest element is: " + result);
        } else {
            System.out.println("The k-th greatest element does not exist.");
        }

        scanner.close();
    }
}
