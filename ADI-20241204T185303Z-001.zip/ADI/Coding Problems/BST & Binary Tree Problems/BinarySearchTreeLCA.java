//Find a lowest common ancestor of a  
//given two nodes in a binary search tree

import java.util.Scanner;

class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int item) {
        value = item;
        left = right = null;
    }
}

class BinarySearchTree{
    TreeNode root;

    // Function to insert a new node with given key
    void insert(int key) {
        root = insertRec(root, key);
    }

    // A utility function to insert a new node with given key
    TreeNode insertRec(TreeNode root, int key) {
        if (root == null) {
            root = new TreeNode(key);
            return root;
        }
        if (key < root.value) {
            root.left = insertRec(root.left, key);
        } else if (key > root.value) {
            root.right = insertRec(root.right, key);
        }
        return root;
    }

    // Function to find the lowest common ancestor of two nodes
    TreeNode findLCA(int n1, int n2) {
        return findLCARec(root, n1, n2);
    }

    TreeNode findLCARec(TreeNode node, int n1, int n2) {
        if (node == null) {
            return null;
        }

        // If both n1 and n2 are smaller than root, then LCA lies in left
        if (n1 < node.value && n2 < node.value) {
            return findLCARec(node.left, n1, n2);
        }

        // If both n1 and n2 are greater than root, then LCA lies in right
        if (n1 > node.value && n2 > node.value) {
            return findLCARec(node.right, n1, n2);
        }

        return node; // This is the LCA
    }
}

public class BinarySearchTreeLCA {
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        Scanner scanner = new Scanner(System.in);

        // Example: Insert values into the BST
        System.out.println("Enter values to insert into the BST (comma separated):");
        String[] values = scanner.nextLine().split(",");
        for (String value : values) {
            bst.insert(Integer.parseInt(value.trim()));
        }

        // User input for nodes to find LCA
        System.out.println("Enter first node value:");
        int n1 = scanner.nextInt();
        System.out.println("Enter second node value:");
        int n2 = scanner.nextInt();

        TreeNode lca = bst.findLCA(n1, n2);
        if (lca != null) {
            System.out.println("Lowest Common Ancestor of " + n1 + " and " + n2 + " is: " + lca.value);
        } else {
            System.out.println("LCA not found for the given nodes.");
        }

        scanner.close();
    }
}
