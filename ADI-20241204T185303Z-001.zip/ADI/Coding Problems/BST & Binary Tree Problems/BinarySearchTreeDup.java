// Create BST contains duplicates

class BinarySearchTreeDup {
    class Node {
        int key;
        Node left, right;

        public Node(int item) {
            key = item;
            left = right = null;
        }
    }

    Node root;

    BinarySearchTreeDup() {
        root = null;
    }

    void insert(int key) {
        root = insertKey(root, key);
    }

    // Insert key in the tree, allowing duplicates
    Node insertKey(Node root, int key) {
        // Return a new node if the tree is empty
        if (root == null) {
            root = new Node(key);
            return root;
        }

        // Traverse to the right place and insert the node
        if (key < root.key) {
            root.left = insertKey(root.left, key);
        } else { // Allow duplicates to be inserted on the right
            root.right = insertKey(root.right, key);
        }

        return root;
    }

    void inorder() {
        inorderRec(root);
    }

    void preorder() {
        preorderRec(root);
    }

    void postorder() {
        postorderRec(root);
    }

    // Inorder Traversal
    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.key + " -> ");
            inorderRec(root.right);
        }
    }

    // Preorder Traversal
    void preorderRec(Node root) {
        if (root != null) {
            System.out.print(root.key + " -> ");
            preorderRec(root.left);
            preorderRec(root.right);
        }
    }

    // Postorder Traversal
    void postorderRec(Node root) {
        if (root != null) {
            postorderRec(root.left);
            postorderRec(root.right);
            System.out.print(root.key + " -> ");
        }
    }

    // Driver Program to test above functions
    public static void main(String[] args) {
        BinarySearchTreeDup tree = new BinarySearchTreeDup();

        tree.insert(8);
        tree.insert(3);
        tree.insert(1);
        tree.insert(6);
        tree.insert(7);
        tree.insert(10);
        tree.insert(14);
        tree.insert(4);
        tree.insert(3); // Inserting a duplicate

        System.out.println();
        System.out.print("Inorder traversal: ");
        tree.inorder();
        System.out.println();
        System.out.print("Preorder traversal: ");
        tree.preorder();
        System.out.println();
        System.out.print("Postorder traversal: ");
        tree.postorder();
        System.out.println();
    }
}
