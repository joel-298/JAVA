  //MCM to find minimum scaler 

import java.util.Scanner;

public class MatrixChainMultiplication {

    // Function to perform matrix chain multiplication using Bottom-Up DP
    public static int matrixChainOrder(int[] dims) {
        int n = dims.length;

        // dp[i][j] will store the minimum number of scalar multiplications needed
        // to multiply matrices Ai...Aj
        int[][] dp = new int[n][n];

        // dp[i][i] is 0 because a single matrix does not require multiplication
        for (int len = 2; len < n; len++) {
            for (int i = 1; i < n - len + 1; i++) {
                int j = i + len - 1;
                dp[i][j] = Integer.MAX_VALUE;

                // Try all possible positions of the last split point
                for (int k = i; k < j; k++) {
                    // q is the cost of multiplying the chain Ai...Ak and Ak+1...Aj
                    int q = dp[i][k] + dp[k + 1][j] + dims[i - 1] * dims[k] * dims[j];
                    if (q < dp[i][j]) {
                        dp[i][j] = q;
                    }
                }
            }
        }

        // The answer is in dp[1][n-1]
        return dp[1][n - 1];
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking user input for the number of matrices
        System.out.print("Enter the number of matrices: ");
        int n = sc.nextInt();

        // The dimensions of the matrices are provided as a sequence.
        // For example: A1 is of dimension p0 x p1, A2 is of dimension p1 x p2, ...
        int[] dims = new int[n + 1];

        // Input the dimensions of the matrices
        System.out.println("Enter the dimensions of the matrices:");
        for (int i = 0; i <= n; i++) {
            dims[i] = sc.nextInt();
        }

        // Compute the minimum number of scalar multiplications
        int result = matrixChainOrder(dims);

        // Output the result
        System.out.println("Minimum number of scalar multiplications is: " + result);
    }
}
