// Climb Stairs using Bottom UP

import java.util.Scanner;

class Climb_Stairs {
    public int climbStairs(int n) {
        if (n == 0 || n == 1) {
            return 1;
        }

        // DP array to store the number of ways to reach each step
        int[] dp = new int[n + 1];
        dp[0] = dp[1] = 1;

        // Fill the DP array based on the recurrence relation
        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }

        // Return the number of ways to reach the nth step
        return dp[n];
    }

    public static void main (String[] args) {
        // Create a scanner object for reading user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user to enter the number of stairs
        System.out.print("Enter the number of stairs: ");
        int n = scanner.nextInt();

        // Create an object of Climb_Stairs class to use the climbStairs method
        Climb_Stairs solution = new Climb_Stairs();

        // Call the climbStairs method and store the result
        int result = solution.climbStairs(n);

        // Output the result
        System.out.println("Number of ways to climb " + n + " stairs: " + result);

        // Close the scanner
        scanner.close();
    }
}
