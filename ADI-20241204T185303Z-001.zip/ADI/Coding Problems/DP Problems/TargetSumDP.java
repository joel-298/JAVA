// TargetSumDP Problem using DP

import java.util.Scanner;

public class TargetSumDP {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] nums = new int[n];
        
        System.out.print("Enter the elements of the array: ");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }
        
        System.out.print("Enter the target value: ");
        int target = scanner.nextInt();
        
        int result = findTargetSumWays(nums, target);
        System.out.println("Number of ways to achieve the target: " + result);
    }
    
    public static int findTargetSumWays(int[] nums, int target) {
        int sum = 0;
        for (int num : nums) {
            sum += num;
        }

        // If the absolute value of target is greater than the sum, or if the sum
        // and target do not have the same parity, it's not possible to achieve the target.
        if (Math.abs(target) > sum || (sum + target) % 2 != 0) {
            return 0;
        }
        
        int newTarget = (sum + target) / 2;
        return countSubsetSum(nums, newTarget);
    }
    
    private static int countSubsetSum(int[] nums, int target) {
        int[] dp = new int[target + 1];
        dp[0] = 1; // There's one way to achieve a target sum of 0: by selecting no elements
        
        for (int num : nums) {
            for (int j = target; j >= num; j--) {
                dp[j] += dp[j - num];
            }
        }
        
        return dp[target];
    }
}
