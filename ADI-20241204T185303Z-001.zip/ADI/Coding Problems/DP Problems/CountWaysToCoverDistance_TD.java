// Count way to Cover Distance using DP Top Down

import java.util.Scanner;

public class CountWaysToCoverDistance_TD {

    // Memoization array to store the number of ways to reach each distance
    private static int[] memo;

    // Recursive method with memoization (Top-Down DP)
    public static int countWays(int n) {
        // Base cases
        if (n == 0) return 1;
        if (n == 1) return 1;
        if (n == 2) return 2;
       

        // If the result for dp[n] is already calculated, return it
        if (memo[n] != -1) {
            return memo[n];
        }

        // Calculate the number of ways for distance n and store the result
        memo[n] = countWays(n - 1) + countWays(n - 2) + countWays(n - 3);
        return memo[n];
    }

    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user for the distance
        System.out.print("Enter the distance: ");
        int distance = scanner.nextInt();

        // Initialize memoization array with -1 (indicating that no value has been computed yet)
        memo = new int[distance + 1];
        for (int i = 0; i <= distance; i++) {
            memo[i] = -1;  // Mark all values as not calculated
        }

        // Compute the number of ways to cover the distance using Top-Down DP
        int result = countWays(distance);

        // Output the result
        System.out.println("Number of ways to cover distance " + distance + " is: " + result);

        // Close the scanner
        scanner.close();
    }
}
