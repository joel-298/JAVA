// TOP DOWN DP for Climb Stairs

import java.util.Scanner;

public class Climb_TD {

    // Memoization array to store the number of ways to reach each step
    private int[] memo;

    public int climbStairs(int n) {
        // Initialize the memoization array with -1 (indicating uncomputed states)
        memo = new int[n + 1];
        for (int i = 0; i <= n; i++) {
            memo[i] = -1;
        }
        
        // Start the recursive function to compute the result
        return climbStairsHelper(n);
    }

    // Recursive function with memoization to compute the number of ways to reach the nth step
    private int climbStairsHelper(int n) {
        // Base case: If we're at step 0 or 1, there's only 1 way to reach the step
        if (n == 0 || n == 1) {
            return 1;
        }
        
        // If the result for this step has already been computed, return it from the memo array
        if (memo[n] != -1) {
            return memo[n];
        }

        // Recursive step: The number of ways to reach the nth step is the sum of the ways
        // to reach the (n-1)th step and the (n-2)th step
        memo[n] = climbStairsHelper(n - 1) + climbStairsHelper(n - 2);

        // Return the computed result for the nth step
        return memo[n];
    }

    public static void main (String[] args) {
        // Create a scanner object for reading user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user to enter the number of stairs
        System.out.print("Enter the number of stairs: ");
        int n = scanner.nextInt();

        // Create an object of Climb_TD class to use the climbStairs method
        Climb_TD solution = Climb_TD ();

        // Call the climbStairs method and store the result
        int result = solution.climbStairs(n);

        // Output the result
        System.out.println("Number of ways to climb " + n + " stairs: " + result);

       }
}
