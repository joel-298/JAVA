// Fibonacci Series using Bottom UP Approach

import java.util.Scanner;

class Fib_BU {
  
    // Function to calculate the nth Fibonacci number using iteration
    static int nthFibonacci(int n) {
        // Handle the edge cases
        if (n <= 1) return n;
      
        // Create an array to store Fibonacci numbers
        int[] dp = new int[n + 1];

        // Initialize the first two Fibonacci numbers
        dp[0] = 0;
        dp[1] = 1;

        // Fill the array iteratively
        for (int i = 2; i <= n; ++i) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }

        // Return the nth Fibonacci number
        return dp[n];
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
	System.out.println("Enter the Value of n :");
	int n = sc.nextInt();
        int result = nthFibonacci(n);
        System.out.println("Nth Term is :"+result);
    }
}
