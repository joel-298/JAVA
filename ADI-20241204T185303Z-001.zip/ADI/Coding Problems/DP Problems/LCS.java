// LCS Problem using DP

import java.util.Scanner;

class LCS {
    public int LongestCommonSubsequence(String text1, String text2) {
        int n = text1.length();
        int m = text2.length();

        // DP table initialization
        int[][] dp = new int[n + 1][m + 1];

        // Fill DP table using dynamic programming approach
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (text1.charAt(i - 1) == text2.charAt(j - 1)) {
                    dp[i][j] = 1 + dp[i - 1][j - 1];  // If characters match, add 1 to diagonal value
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);  // Else take max of top or left
                }
            }
        }
        // The length of the longest common subsequence will be in dp[n][m]
        return dp[n][m];
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input from the user
        System.out.print("Enter the first string (text1): ");
        String text1 = scanner.nextLine();

        System.out.print("Enter the second string (text2): ");
        String text2 = scanner.nextLine();

        // Create an object of LCS class
        LCS solution = new LCS();

        // Call the method to find LCS length
        int result = solution.LongestCommonSubsequence(text1, text2);

        // Output the result
        System.out.println("The length of the Longest Common Subsequence is: " + result);

        scanner.close();  // Close the scanner
    }
}
