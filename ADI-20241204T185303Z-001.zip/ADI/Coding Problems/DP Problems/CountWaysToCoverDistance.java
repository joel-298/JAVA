// Count way to Cover Distance using DP Bottom UP

import java.util.Scanner;

public class CountWaysToCoverDistance {

    public static int countWays(int n) {
      
        // DP array to store the number of ways to reach each distance
        int[] dp = new int[n + 1];

        // Base cases
        dp[0] = 1;  // 1 way to cover distance 0 (doing nothing)
        dp[1] = 1;  // 1 way to cover distance 1
        dp[2] = 2;  // 2 ways to cover distance 2
        
        // Fill the dp array for distances greater than 3
        for (int i = 3; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2] + dp[i - 3];
        }

        // The result will be stored in dp[n]
        return dp[n];
    }

    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user for the distance
        System.out.print("Enter the distance: ");
        int distance = scanner.nextInt();

        // Compute the number of ways to cover the distance
        int result = countWays(distance);

        // Output the result
        System.out.println("Number of ways to cover distance " + distance + " is: " + result);
    }
}
