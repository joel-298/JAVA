import java.util.Scanner;

class BellmanFord {

    public static void bellmanFord(int vertices, int[][] edges, int source) {
        int[] dist = new int[vertices];
        
        // Initialize distances to all vertices as infinity, except the source vertex
        for (int i = 0; i < vertices; i++) {
            dist[i] = Integer.MAX_VALUE;
        }
        dist[source] = 0;

        // Relax all edges |V| - 1 times
        for (int i = 1; i < vertices; i++) {
            for (int[] edge : edges) {
                int u = edge[0];  // Start vertex of the edge
                int v = edge[1];  // End vertex of the edge
                int weight = edge[2];  // Weight of the edge
                
                // If we find a shorter path to v, update dist[v]
                if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                }
            }
        }

        // Output the shortest distances from source vertex
        System.out.println("Shortest distances from vertex " + source + ":");
        for (int i = 0; i < vertices; i++) {
            if (dist[i] == Integer.MAX_VALUE) {
                System.out.println("Vertex " + i + " -> No path");
            } else {
                System.out.println("Vertex " + i + " -> " + dist[i]);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input: Number of vertices
        System.out.print("Enter number of vertices: ");
        int vertices = scanner.nextInt();

        // Input: Number of edges
        System.out.print("Enter number of edges: ");
        int edgesCount = scanner.nextInt();

        // Input: Edges
        int[][] edges = new int[edgesCount][3];
        System.out.println("Enter edges (start vertex, end vertex, weight):");
        for (int i = 0; i < edgesCount; i++) {
            edges[i][0] = scanner.nextInt();  // Start vertex
            edges[i][1] = scanner.nextInt();  // End vertex
            edges[i][2] = scanner.nextInt();  // Weight of the edge
        }

        // Input: Source vertex
        System.out.print("Enter source vertex: ");
        int source = scanner.nextInt();

        // Run Bellman-Ford algorithm
        bellmanFord(vertices, edges, source);
    }
}
