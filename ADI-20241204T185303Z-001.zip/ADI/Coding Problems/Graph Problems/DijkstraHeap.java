import java.util.*;

class DijkstraHeap {
    static class Edge {
        int destination, weight;

        public Edge(int destination, int weight) {
            this.destination = destination;
            this.weight = weight;
        }
    }

    public static void dijkstra(List<List<Edge>> graph, int startVertex) {
        int n = graph.size();
        int[] dist = new int[n];
        Arrays.fill(dist, Integer.MAX_VALUE);  // Initialize distances to infinity
        dist[startVertex] = 0;

        // PriorityQueue with min-heap behavior
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        pq.add(new int[] {startVertex, 0});

        while (!pq.isEmpty()) {
            int[] node = pq.poll();
            int u = node[0];  // current vertex
            int distanceU = node[1];  // distance to current vertex

            // If the current distance is already greater than the known shortest distance, skip it
            if (distanceU > dist[u]) continue;

            for (Edge edge : graph.get(u)) {
                int v = edge.destination;
                int weight = edge.weight;

                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    pq.add(new int[] {v, dist[v]});
                }
            }
        }

        // Print the results
        System.out.println("Shortest distances from vertex " + startVertex + ":");
        for (int i = 0; i < n; i++) {
            if (dist[i] == Integer.MAX_VALUE) {
                System.out.println("Vertex " + i + " is unreachable.");
            } else {
                System.out.println("Vertex " + i + " : " + dist[i]);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input: number of vertices
        System.out.print("Enter the number of vertices: ");
        int n = scanner.nextInt();

        // Input: number of edges
        System.out.print("Enter the number of edges: ");
        int m = scanner.nextInt();

        // Create the graph (adjacency list)
        List<List<Edge>> graph = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            graph.add(new ArrayList<>());
        }

        // Input: edges (u, v, weight)
        System.out.println("Enter the edges (u v weight):");
        for (int i = 0; i < m; i++) {
            int u = scanner.nextInt();
            int v = scanner.nextInt();
            int weight = scanner.nextInt();
            graph.get(u).add(new Edge(v, weight));
            graph.get(v).add(new Edge(u, weight));  // Since it's undirected
        }

        // Input: start vertex
        System.out.print("Enter the start vertex: ");
        int startVertex = scanner.nextInt();

        // Run Dijkstra's Algorithm
        dijkstra(graph, startVertex);

        scanner.close();
    }
}
