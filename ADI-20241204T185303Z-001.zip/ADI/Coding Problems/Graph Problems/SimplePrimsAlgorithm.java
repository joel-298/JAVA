import java.util.Scanner;

public class SimplePrimsAlgorithm {

    // Method to find the vertex with the minimum key value
    static int minKey(int[] key, boolean[] includedInMST, int V) {
        int min = Integer.MAX_VALUE, minIndex = -1;

        for (int v = 0; v < V; v++) {
            if (!includedInMST[v] && key[v] < min) {
                min = key[v];
                minIndex = v;
            }
        }
        return minIndex;
    }

    // Method to implement Prim's Algorithm
    static void primMST(int[][] graph, int V) {
        int[] parent = new int[V];  // To store the parent of each vertex in MST
        int[] key = new int[V];     // To store the minimum weight of edges
        boolean[] includedInMST = new boolean[V]; // To track vertices included in MST

        // Initialize the key values as infinite and parent as -1
        for (int i = 0; i < V; i++) {
            key[i] = Integer.MAX_VALUE;
            includedInMST[i] = false;
        }

        key[0] = 0;  // Start from vertex 0
        parent[0] = -1;  // No parent for the starting vertex

        // Loop over all vertices to construct the MST
        for (int count = 0; count < V - 1; count++) {
            int u = minKey(key, includedInMST, V);  // Pick the vertex with the minimum key value
            includedInMST[u] = true;  // Include vertex u in MST

            // Update the key and parent values of adjacent vertices
            for (int v = 0; v < V; v++) {
                if (graph[u][v] != 0 && !includedInMST[v] && graph[u][v] < key[v]) {
                    key[v] = graph[u][v];
                    parent[v] = u;
                }
            }
        }

        // Print the edges of the MST
        System.out.println("Edges in MST:");
        int cost = 0;
        for (int i = 1; i < V; i++) {
            // Check if a valid parent exists (for isolated nodes, the parent may be -1)
            if (parent[i] != -1) {
                System.out.println(parent[i] + " - " + i + " : " + graph[i][parent[i]]);
                cost += graph[i][parent[i]];
            }
        }
        System.out.println("MST Cost: " + cost);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input number of vertices
        System.out.print("Enter number of vertices: ");
        int V = sc.nextInt();

        // Create graph as an adjacency matrix
        int[][] graph = new int[V][V];

        // Input the edges and their weights
        System.out.print("Enter the number of edges: ");
        int E = sc.nextInt();
        System.out.println("Enter the edges (vertex1 vertex2 weight):");

        for (int i = 0; i < E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            int weight = sc.nextInt();

            // Ensure the indices are valid
            if (u >= 0 && u < V && v >= 0 && v < V) {
                graph[u][v] = weight;
                graph[v][u] = weight;  // Since the graph is undirected
            } else {
                System.out.println("Invalid edge: " + u + " - " + v);
            }
        }

        // Run Prim's Algorithm
        primMST(graph, V);
    }
}
