import java.util.*;

public class TopologicalSortDFS {

    // Perform DFS and store nodes in a stack
    private static void dfs(int node, boolean[] visited, Stack<Integer> stack, List<List<Integer>> graph) {
        visited[node] = true;

        // Visit all the neighbors of the node
        for (int neighbor : graph.get(node)) {
            if (!visited[neighbor]) {
                dfs(neighbor, visited, stack, graph);
            }
        }

        // Push the node to the stack after visiting all its neighbors
        stack.push(node);
    }

    // Main function for Topological Sort
    public static List<Integer> topologicalSort(int numNodes, List<List<Integer>> graph) {
        boolean[] visited = new boolean[numNodes];
        Stack<Integer> stack = new Stack<>();

        // Call DFS for every node
        for (int i = 0; i < numNodes; i++) {
            if (!visited[i]) {
                dfs(i, visited, stack, graph);
            }
        }

        // Extract the topological order
        List<Integer> topOrder = new ArrayList<>();
        while (!stack.isEmpty()) {
            topOrder.add(stack.pop());
        }
        return topOrder;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input: Number of nodes and edges
        System.out.print("Enter number of nodes: ");
        int numNodes = sc.nextInt();
        
        System.out.print("Enter number of edges: ");
        int numEdges = sc.nextInt();
        
        // Create an adjacency list for the graph
        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < numNodes; i++) {
            graph.add(new ArrayList<>());
        }
        
        // Input edges
        System.out.println("Enter edges (u v): ");
        for (int i = 0; i < numEdges; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            graph.get(u).add(v);  // Add directed edge u -> v
        }

        // Get topological sorting
        List<Integer> topOrder = topologicalSort(numNodes, graph);

        // Output the topological sort
        System.out.println("Topological Sorting:");
        for (int node : topOrder) {
            System.out.print(node + " ");
        }

        sc.close();
    }
}
