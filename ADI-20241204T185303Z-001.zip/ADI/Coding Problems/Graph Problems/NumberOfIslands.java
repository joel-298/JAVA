import java.util.Scanner;

public class NumberOfIslands {
    
    // DFS function to mark all connected land cells as visited
    public static void dfs(int[][] grid, int i, int j) {
        // Check if the current cell is out of bounds or water
        if (i < 0 || i >= grid.length || j < 0 || j >= grid[0].length || grid[i][j] == 0) {
            return;
        }

        // Mark the current cell as visited by setting it to water (0)
        grid[i][j] = 0;

        // Visit all 4 neighbors (up, down, left, right)
        dfs(grid, i + 1, j); // down
        dfs(grid, i - 1, j); // up
        dfs(grid, i, j + 1); // right
        dfs(grid, i, j - 1); // left
    }

    // Function to count the number of islands
    public static int countIslands(int[][] grid) {
        int islandCount = 0;
        
        // Traverse the grid
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                // If we find a land cell (1), start a DFS to mark the whole island
                if (grid[i][j] == 1) {
                    islandCount++;
                    dfs(grid, i, j); // Mark all cells of the current island
                }
            }
        }
        return islandCount;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input grid dimensions
        System.out.print("Enter number of rows: ");
        int rows = scanner.nextInt();
        System.out.print("Enter number of columns: ");
        int cols = scanner.nextInt();
        
        // Input grid
        int[][] grid = new int[rows][cols];
        System.out.println("Enter the grid (1 for land, 0 for water):");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                grid[i][j] = scanner.nextInt();
            }
        }
        
        // Calculate number of islands
        int numberOfIslands = countIslands(grid);
        System.out.println("Number of islands: " + numberOfIslands);
    }
}
