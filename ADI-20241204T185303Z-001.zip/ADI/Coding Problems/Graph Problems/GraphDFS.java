import java.util.*;

public class GraphDFS {
    
    // DFS traversal using recursion
    public static void dfs(int node, boolean[] visited, List<List<Integer>> graph) {
        // Mark the current node as visited
        visited[node] = true;
        
        // Print the node
        System.out.print(node + " ");
        
        // Visit all the adjacent nodes (neighbors)
        for (int neighbor : graph.get(node)) {
            if (!visited[neighbor]) {
                dfs(neighbor, visited, graph);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of nodes in the graph: ");
        int numNodes = scanner.nextInt();
        
        // Create an empty graph (adjacency list)
        List<List<Integer>> graph = new ArrayList<>();
        
        // Initialize the adjacency list for each node
        for (int i = 0; i < numNodes; i++) {
            graph.add(new ArrayList<>());
        }
        
        System.out.print("Enter the number of edges: ");
        int numEdges = scanner.nextInt();
        
        System.out.println("Enter the edges (format: node1 node2): ");
        for (int i = 0; i < numEdges; i++) {
            int node1 = scanner.nextInt();
            int node2 = scanner.nextInt();
            
            graph.get(node1).add(node2);  // Add an edge from node1 to node2
            graph.get(node2).add(node1);  // Add an edge from node2 to node1 (undirected graph)
        }
        
        System.out.print("Enter the starting node for DFS: ");
        int startNode = scanner.nextInt();
        
        // Create a visited array to keep track of visited nodes
        boolean[] visited = new boolean[numNodes];
        
        // Perform DFS from the starting node
        System.out.println("DFS Traversal starting from node " + startNode + ":");
        dfs(startNode, visited, graph);
        
        scanner.close();
    }
}
