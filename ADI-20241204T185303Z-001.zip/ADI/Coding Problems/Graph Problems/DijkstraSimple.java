import java.util.Scanner;

public class DijkstraSimple {

    public static void dijkstra(int[][] graph, int startVertex, int numVertices) {
        int[] dist = new int[numVertices];  // Stores shortest distances from start vertex
        boolean[] visited = new boolean[numVertices];  // Tracks visited vertices

        // Initialize all distances to infinity and visited to false
        for (int i = 0; i < numVertices; i++) {
            dist[i] = Integer.MAX_VALUE;
            visited[i] = false;
        }
        dist[startVertex] = 0;  // Distance to start vertex is 0

        // Find the shortest path for each vertex
        for (int count = 0; count < numVertices - 1; count++) {
            int minDist = Integer.MAX_VALUE, u = -1;

            // Find the vertex with the smallest distance
            for (int v = 0; v < numVertices; v++) {
                if (!visited[v] && dist[v] < minDist) {
                    minDist = dist[v];
                    u = v;
                }
            }

            visited[u] = true;  // Mark the vertex as visited

            // Update distances of neighboring vertices
            for (int v = 0; v < numVertices; v++) {
                if (!visited[v] && graph[u][v] != 0 && dist[u] + graph[u][v] < dist[v]) {
                    dist[v] = dist[u] + graph[u][v];
                }
            }
        }

        // Output the shortest distances from the start vertex
        System.out.println("Shortest distances from vertex " + startVertex + ":");
        for (int i = 0; i < numVertices; i++) {
            System.out.println(i + " -> " + (dist[i] == Integer.MAX_VALUE ? "No path" : dist[i]));
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Get the number of vertices
        System.out.print("Enter number of vertices: ");
        int numVertices = sc.nextInt();

        // Create the graph (adjacency matrix)
        int[][] graph = new int[numVertices][numVertices];
        System.out.println("Enter the adjacency matrix (0 for no edge, other numbers for weights):");
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
		System.out.print("Enter Edge weight from vertex " + i + " to " + j + ": ");
                graph[i][j] = sc.nextInt();
	    } 
        }

        // Get the start vertex
        System.out.print("Enter the start vertex: ");
        int startVertex = sc.nextInt();

        // Run Dijkstra's Algorithm
        dijkstra(graph, startVertex, numVertices);
    }
}
