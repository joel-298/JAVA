import java.util.*;

class Graph {
    int V; // Number of vertices
    List<int[]>[] adjList;

    // Constructor to initialize graph
    public Graph(int V) {
        this.V = V;
        adjList = new ArrayList[V];
        for (int i = 0; i < V; i++) {
            adjList[i] = new ArrayList<>();
        }
    }

    // Method to add an edge
    public void addEdge(int u, int v, int weight) {
        adjList[u].add(new int[]{v, weight});
        adjList[v].add(new int[]{u, weight});
    }

    // Method to run Prim's Algorithm and print the MST edges
    public void primsMST(int startVertex) {
        // Priority queue to get the edge with the minimum weight
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(e -> e[1]));

        // To track if a vertex is included in the MST
        boolean[] inMST = new boolean[V];

        // To store the edges of the MST
        List<String> mstEdges = new ArrayList<>();
        int mstWeight = 0;

        // Start by adding the start vertex with weight 0
        pq.add(new int[]{startVertex, 0});
        
        // Count of edges in MST
        int edgesInMST = 0;

        while (!pq.isEmpty() && edgesInMST < V - 1) { // Stop when we have V-1 edges in MST
            int[] edge = pq.poll();
            int u = edge[0];
            int weight = edge[1];

            // Skip if the vertex is already in MST
            if (inMST[u]) continue;

            // Include vertex in MST
            inMST[u] = true;
            mstWeight += weight;
            edgesInMST++;

            // Add all adjacent vertices to the priority queue
            for (int[] neighbor : adjList[u]) {
                int v = neighbor[0];
                int w = neighbor[1];
                if (!inMST[v]) {
                    pq.add(new int[]{v, w});
                    // Record the edge from u to v with weight w, but only the connecting edges
                    if (weight != 0) { // Don't add the dummy edge for the start vertex
                        mstEdges.add(u + " - " + v + " : " + w);
                    }
                }
            }
        }

        // Print the edges of the MST
        System.out.println("Edges in the Minimum Spanning Tree:");
        for (String edge : mstEdges) {
            System.out.println(edge);
        }
        System.out.println("Total weight of MST: " + mstWeight);
    }
}

public class PrimMSTPriority {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number of vertices:");
        int V = sc.nextInt();

        Graph graph = new Graph(V);

        System.out.println("Enter number of edges:");
        int E = sc.nextInt();

        System.out.println("Enter edges (source destination weight):");
        for (int i = 0; i < E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            int weight = sc.nextInt();
            graph.addEdge(u, v, weight);
        }

        // Run Prim's Algorithm starting from vertex 0
        graph.primsMST(0);

        sc.close();
    }
}
