//DFS

import java.util.*;

public class SimpleDFS {

    // DFS using iteration (stack-based approach)
    public static void dfs(int startNode, List<List<Integer>> graph) {
        // Set up visited array to keep track of visited nodes
        boolean[] visited = new boolean[graph.size()];
        
        // Stack to hold nodes to be processed
        Stack<Integer> stack = new Stack<>();
        
        // Start DFS from the starting node
        stack.push(startNode);
        
        while (!stack.isEmpty()) {
            int node = stack.pop();
            
            // If the node is not visited, process it
            if (!visited[node]) {
                System.out.print(node + " ");
                visited[node] = true;
            }
            
            // Add all unvisited neighbors to the stack
            for (int neighbor : graph.get(node)) {
                if (!visited[neighbor]) {
                    stack.push(neighbor);
                }
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read number of nodes
        System.out.print("Enter the number of nodes in the graph: ");
        int numNodes = scanner.nextInt();
        
        // Create the adjacency list for the graph
        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < numNodes; i++) {
            graph.add(new ArrayList<>());
        }
        
        // Read number of edges
        System.out.print("Enter the number of edges: ");
        int numEdges = scanner.nextInt();
        
        // Read the edges
        System.out.println("Enter the edges (format: node1 node2): ");
        for (int i = 0; i < numEdges; i++) {
            int node1 = scanner.nextInt();
            int node2 = scanner.nextInt();
            
            // Add an undirected edge between node1 and node2
            graph.get(node1).add(node2);
            graph.get(node2).add(node1);
        }
        
        // Read the starting node for DFS
        System.out.print("Enter the starting node for DFS: ");
        int startNode = scanner.nextInt();
        
        // Perform DFS from the starting node
        System.out.println("DFS Traversal starting from node " + startNode + ":");
        dfs(startNode, graph);
      }
}
