import java.util.*;

public class TopologicalSort {

    // Function to perform Topological Sort using Kahn's Algorithm (BFS approach)
    public static void topologicalSort(int V, List<List<Integer>> adj) {
        int[] inDegree = new int[V];
        
        // Compute in-degree (number of incoming edges) for each vertex
        for (int u = 0; u < V; u++) {
            for (int v : adj.get(u)) {
                inDegree[v]++;
            }
        }
        
        // Queue to store all vertices with no incoming edges
        Queue<Integer> queue = new LinkedList<>();
        
        // Add all vertices with in-degree 0 to the queue
        for (int i = 0; i < V; i++) {
            if (inDegree[i] == 0) {
                queue.offer(i);
            }
        }
        
        List<Integer> topologicalOrder = new ArrayList<>();
        
        // Process the vertices
        while (!queue.isEmpty()) {
            int u = queue.poll();
            topologicalOrder.add(u);
            
            // Decrease in-degree of neighbors and add to queue if in-degree becomes 0
            for (int v : adj.get(u)) {
                inDegree[v]--;
                if (inDegree[v] == 0) {
                    queue.offer(v);
                }
            }
        }
        
        // If topologicalOrder doesn't contain all vertices, there's a cycle in the graph
        if (topologicalOrder.size() != V) {
            System.out.println("The graph has a cycle. Topological sorting is not possible.");
        } else {
            System.out.println("Topological Sort:");
            for (int vertex : topologicalOrder) {
                System.out.print(vertex + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking number of vertices (V) and edges (E) as input
        System.out.print("Enter number of vertices (V): ");
        int V = scanner.nextInt();
        
        System.out.print("Enter number of edges (E): ");
        int E = scanner.nextInt();
        
        // Create adjacency list representation of the graph
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i < V; i++) {
            adj.add(new ArrayList<>());
        }

        System.out.println("Enter the edges (u v) where there is an edge from u to v:");
        for (int i = 0; i < E; i++) {
            int u = scanner.nextInt();
            int v = scanner.nextInt();
            adj.get(u).add(v); // Add edge u -> v
        }

        // Perform topological sorting
        topologicalSort(V, adj);
    }
}
