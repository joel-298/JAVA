import java.util.Scanner;

public class FloydWarshall {

    // Method to perform Floyd-Warshall algorithm
    public static void floydWarshall(int graph[][], int V) {
        // dist[][] will store the shortest distance between every pair of vertices
        int dist[][] = new int[V][V];

        // Initialize the solution matrix to be the same as the input graph matrix
        // The matrix dist will be modified to reflect the shortest distances
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                dist[i][j] = graph[i][j];
            }
        }

        // Floyd-Warshall algorithm
        for (int k = 0; k < V; k++) {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    if (dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }

        // Print the shortest distance matrix
        printSolution(dist, V);
    }

    // Method to print the solution matrix
    public static void printSolution(int dist[][], int V) {
        System.out.println("The shortest distance matrix is:");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (dist[i][j] == Integer.MAX_VALUE) {
                    System.out.print("INF "); // INF means no path
                } else {
                    System.out.print(dist[i][j] + " ");
                }
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the number of vertices (V)
        System.out.print("Enter the number of vertices: ");
        int V = scanner.nextInt();

        // Create the adjacency matrix for the graph
        int graph[][] = new int[V][V];

        // Get the graph input from the user
        System.out.println("Enter the adjacency matrix (use a large number for infinity, e.g., 9999 for no edge):");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                graph[i][j] = scanner.nextInt();
            }
        }

        // Run Floyd-Warshall algorithm
        floydWarshall(graph, V);
        
        scanner.close();
    }
}
