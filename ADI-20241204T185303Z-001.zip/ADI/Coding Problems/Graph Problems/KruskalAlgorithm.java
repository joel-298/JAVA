import java.util.*;

public class KruskalAlgorithm {

    // A class to represent an edge in the graph
    static class Edge {
        int src, dest, weight;

        public Edge(int src, int dest, int weight) {
            this.src = src;
            this.dest = dest;
            this.weight = weight;
        }
    }

    // A class to represent a disjoint set (Union-Find) for cycle detection
    static class DisjointSet {
        int[] parent, rank;

        public DisjointSet(int n) {
            parent = new int[n];
            rank = new int[n];
            for (int i = 0; i < n; i++) {
                parent[i] = i;
                rank[i] = 0;
            }
        }

        // Find the representative of the set containing element i
        public int find(int i) {
            if (parent[i] != i) {
                parent[i] = find(parent[i]); // Path compression
            }
            return parent[i];
        }

        // Union of two subsets
        public void union(int x, int y) {
            int rootX = find(x);
            int rootY = find(y);

            if (rootX != rootY) {
                // Union by rank
                if (rank[rootX] > rank[rootY]) {
                    parent[rootY] = rootX;
                } else if (rank[rootX] < rank[rootY]) {
                    parent[rootX] = rootY;
                } else {
                    parent[rootY] = rootX;
                    rank[rootX]++;
                }
            }
        }
    }

    // Method to implement Kruskal's Algorithm
    static void kruskal(int V, List<Edge> edges) {
        // Step 1: Sort edges by their weight
        Collections.sort(edges, Comparator.comparingInt(e -> e.weight));

        DisjointSet ds = new DisjointSet(V);
        List<Edge> mst = new ArrayList<>();

        // Step 2: Process edges, adding to MST if no cycle is formed
        for (Edge edge : edges) {
            int srcRoot = ds.find(edge.src);
            int destRoot = ds.find(edge.dest);

            // If adding this edge doesn't form a cycle, include it in the MST
            if (srcRoot != destRoot) {
                mst.add(edge);
                ds.union(srcRoot, destRoot);
            }
        }

        // Output the MST
        System.out.println("Edges in the MST:");
        int mstWeight = 0;
        for (Edge edge : mst) {
            System.out.println(edge.src + " - " + edge.dest + " : " + edge.weight);
            mstWeight += edge.weight;
        }
        System.out.println("Total weight of MST: " + mstWeight);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input number of vertices
        System.out.print("Enter the number of vertices: ");
        int V = sc.nextInt();

        // Input number of edges
        System.out.print("Enter the number of edges: ");
        int E = sc.nextInt();

        List<Edge> edges = new ArrayList<>();

        // Input edges and their weights
        System.out.println("Enter the edges (src dest weight):");
        for (int i = 0; i < E; i++) {
            int src = sc.nextInt();
            int dest = sc.nextInt();
            int weight = sc.nextInt();
            edges.add(new Edge(src, dest, weight));
        }

        // Run Kruskal's algorithm to find the MST
        kruskal(V, edges);
    }
}
