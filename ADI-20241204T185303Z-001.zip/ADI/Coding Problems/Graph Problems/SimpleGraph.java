import java.util.Scanner;

public class SimpleGraph {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Input the number of vertices
        System.out.print("Enter the number of vertices: ");
        int n = sc.nextInt();
        
        // Initialize the adjacency matrix
        int[][] adjMatrix = new int[n+1][n+1];
        
        // Input the edges
        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();
        
        for (int i = 0; i < edges; i++) {
            System.out.print("Enter source vertex of edge " + (i + 1) + ": ");
            int source = sc.nextInt();
            System.out.print("Enter destination vertex of edge " + (i + 1) + ": ");
            int destination = sc.nextInt();
            
            // Mark the edge in the adjacency matrix (undirected graph)
            adjMatrix[source][destination] = 1;
            adjMatrix[destination][source] = 1;
        }
        
        // Display the adjacency matrix
        System.out.println("Adjacency Matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(adjMatrix[i][j] + " ");
            }
            System.out.println();
        }
     }
}
