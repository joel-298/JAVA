import java.util.Scanner;

public class SimpleFloydWarshall {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input: Number of vertices
        System.out.print("Enter the number of vertices: ");
        int V = scanner.nextInt();

        // Input: Adjacency matrix (graph)
        int[][] graph = new int[V][V];
        System.out.println("Enter the adjacency matrix (use a large number for infinity, e.g., 9999 for no edge):");
        for (int i = 0; i < V; i++) {
	   System.out.print("Enter the Weights of edge from Vertex "+(i+1)+" : ");
            for (int j = 0; j < V; j++) {
                graph[i][j] = scanner.nextInt();
            }
        }

        // Floyd-Warshall Algorithm
        for (int k = 0; k < V; k++) {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    if (graph[i][k] + graph[k][j] < graph[i][j]) {
                        graph[i][j] = graph[i][k] + graph[k][j];
                    }
                }
            }
        }

        // Output: Shortest path matrix
        System.out.println("Shortest distances between every pair of vertices:");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (graph[i][j] == 9999) {
                    System.out.print("INF ");
                } else {
                    System.out.print(graph[i][j] + " ");
                }
            }
            System.out.println();
        }
     }
}
