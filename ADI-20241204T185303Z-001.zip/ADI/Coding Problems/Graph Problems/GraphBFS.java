import java.util.*;

public class GraphBFS {
    private static Map<Integer, List<Integer>> graph;

    // BFS implementation
    public static void bfs(int startNode) {
        Set<Integer> visited = new HashSet<>();
        Queue<Integer> queue = new LinkedList<>();

        visited.add(startNode);
        queue.offer(startNode);

        System.out.println("BFS Traversal starting from node " + startNode + ":");

        while (!queue.isEmpty()) {
            int node = queue.poll();
            System.out.print(node + " ");

            // Get all adjacent nodes
            List<Integer> neighbors = graph.get(node);
            if (neighbors != null) {
                for (int neighbor : neighbors) {
                    if (!visited.contains(neighbor)) {
                        visited.add(neighbor);
                        queue.offer(neighbor);
                    }
                }
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        graph = new HashMap<>();
        System.out.print("Enter the number of nodes in the graph: ");
        int numNodes = scanner.nextInt();

        // Initialize graph with empty lists
        for (int i = 1; i <= numNodes; i++) {
            graph.put(i, new ArrayList<>());
        }

        // Input edges
        System.out.print("Enter the number of edges: ");
        int numEdges = scanner.nextInt();
        System.out.println("Enter the edges (format: node1 node2): ");
        for (int i = 0; i < numEdges; i++) {
            int node1 = scanner.nextInt();
            int node2 = scanner.nextInt();
            graph.get(node1).add(node2);  // Add edge from node1 to node2
            graph.get(node2).add(node1);  // Add edge from node2 to node1 (since it's an undirected graph)
        }

        // Get starting node for BFS
        System.out.print("Enter the starting node for BFS: ");
        int startNode = scanner.nextInt();

        // Perform BFS from the start node
        bfs(startNode);
    }
}
