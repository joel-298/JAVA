import java.util.*;

public class SimpleBFS {
    
    // Perform BFS traversal from the start node
    public static void bfs(int startNode, List<List<Integer>> graph) {
        // To track visited nodes
        boolean[] visited = new boolean[graph.size()];
        
        // Create a queue for BFS
        Queue<Integer> queue = new LinkedList<>();
        
        // Start from the given node
        visited[startNode] = true;
        queue.offer(startNode);
        
        System.out.println("BFS Traversal starting from node " + startNode + ":");
        
        while (!queue.isEmpty()) {
            // Dequeue a node
            int node = queue.poll();
            System.out.print(node + " ");
            
            // Visit all adjacent nodes of the dequeued node
            for (int neighbor : graph.get(node)) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    queue.offer(neighbor);
                }
            }
        }
        System.out.println();  // Move to the next line after BFS output
    }
    
    // Function to print the adjacency list (graph)
    public static void printGraph(List<List<Integer>> graph) {
        System.out.println("Graph (Adjacency List):");
        for (int i = 0; i < graph.size(); i++) {
            System.out.print(i + ": ");
            for (int neighbor : graph.get(i)) {
                System.out.print(neighbor + " ");
            }
            System.out.println();  // Move to the next line after each node's neighbors
        }
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get the number of nodes
        System.out.print("Enter the number of nodes in the graph: ");
        int numNodes = scanner.nextInt();
        
        if (numNodes <= 0) {
            System.out.println("Invalid number of nodes. Exiting.");
            return;
        }
        
        // Create an empty graph (adjacency list)
        List<List<Integer>> graph = new ArrayList<>();
        
        for (int i = 0; i < numNodes; i++) {
            graph.add(new ArrayList<>());
        }
        
        // Get the number of edges
        System.out.print("Enter the number of edges: ");
        int numEdges = scanner.nextInt();
        
        System.out.println("Enter the edges (format: node1 node2): ");
        
        // Reading edges and constructing the graph
        for (int i = 0; i < numEdges; i++) {
            int node1 = scanner.nextInt();
            int node2 = scanner.nextInt();
            
            if (node1 < 0 || node1 >= numNodes || node2 < 0 || node2 >= numNodes) {
                System.out.println("Invalid edge between " + node1 + " and " + node2 + ". Please enter valid nodes.");
                i--; // Decrement the counter to re-enter the invalid edge
                continue;
            }
            
            graph.get(node1).add(node2);  // Add an edge from node1 to node2
            graph.get(node2).add(node1);  // Add an edge from node2 to node1 (undirected graph)
        }
        
        // Print the adjacency list (graph)
        printGraph(graph);
        
        // Get the starting node for BFS
        System.out.print("Enter the starting node for BFS: ");
        int startNode = scanner.nextInt();
        
        if (startNode < 0 || startNode >= numNodes) {
            System.out.println("Invalid starting node. Exiting.");
            return;
        }
        
        // Perform BFS starting from the given node
        bfs(startNode, graph);
        
        scanner.close();
    }
}
