import java.util.*;

class Edge {
    int source, destination, weight;

    public Edge(int source, int destination, int weight) {
        this.source = source;
        this.destination = destination;
        this.weight = weight;
    }
}

public class SimpleKruskal {

    // Find function to get the root of a node
    static int findParent(int[] parent, int node) {
        if (parent[node] == node) {
            return node;
        }
        return parent[node] = findParent(parent, parent[node]); // Path compression
    }

    // Union function to join two sets
    static void union(int[] parent, int x, int y) {
        int rootX = findParent(parent, x);
        int rootY = findParent(parent, y);

        // If they belong to different sets, join them
        if (rootX != rootY) {
            parent[rootX] = rootY;
        }
    }

    // Kruskal's algorithm to find MST
    static void kruskal(int vertices, List<Edge> edges) {
        // Sort edges by weight
        edges.sort(Comparator.comparingInt(edge -> edge.weight));

        // Initialize parent array for union-find
        int[] parent = new int[vertices];
        for (int i = 0; i < vertices; i++) {
            parent[i] = i; // Initially, each vertex is its own parent
        }

        int totalWeight = 0;
        System.out.println("MST Edges:");

        // Process each edge
        for (Edge edge : edges) {
            int rootSource = findParent(parent, edge.source);
            int rootDestination = findParent(parent, edge.destination);

            // If the nodes are in different sets, include this edge in MST
            if (rootSource != rootDestination) {
                System.out.println(edge.source + " - " + edge.destination + " : " + edge.weight);
                totalWeight += edge.weight;
                union(parent, edge.source, edge.destination);
            }
        }

        System.out.println("Total weight of MST: " + totalWeight);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of vertices: ");
        int vertices = sc.nextInt();  // Number of vertices

        System.out.print("Enter number of edges: ");
        int edgesCount = sc.nextInt();  // Number of edges

        List<Edge> edges = new ArrayList<>();

        System.out.println("Enter edges (source, destination, weight):");
        for (int i = 0; i < edgesCount; i++) {
            int u = sc.nextInt(); // Source vertex
            int v = sc.nextInt(); // Destination vertex
            int w = sc.nextInt(); // Weight of the edge
            edges.add(new Edge(u, v, w));
        }

        // Run Kruskal's algorithm to find the MST
        kruskal(vertices, edges);
    }
}
