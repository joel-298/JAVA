import java.util.Scanner;
import java.util.Arrays;

public class PrimsAlgorithm {

    // Method to find the vertex with the minimum key value
    static int minKey(int[] key, boolean[] mstSet, int V) {
        int min = Integer.MAX_VALUE, minIndex = -1;

        for (int v = 0; v < V; v++) {
            if (!mstSet[v] && key[v] < min) {
                min = key[v];
                minIndex = v;
            }
        }
        return minIndex;
    }

    // Method to implement Prim's Algorithm
    static void primMST(int[][] graph, int V) {
        int[] parent = new int[V];  // Array to store constructed MST
        int[] key = new int[V];     // Key values used to pick minimum weight edge
        boolean[] mstSet = new boolean[V]; // To represent the vertices not yet included in MST

        // Initialize all key values to infinity
        Arrays.fill(key, Integer.MAX_VALUE);
        key[0] = 0;  // Make the first vertex as the source
        parent[0] = -1;  // First node is always root of MST

        // The MST will have V vertices
        for (int count = 0; count < V - 1; count++) {
            // Pick the minimum key vertex that is not yet included in MST
            int u = minKey(key, mstSet, V);

            // Add the picked vertex to the MST Set
            mstSet[u] = true;

            // Update the key and parent values of the adjacent vertices of the picked vertex
            for (int v = 0; v < V; v++) {
                if (graph[u][v] != 0 && !mstSet[v] && graph[u][v] < key[v]) {
                    parent[v] = u;
                    key[v] = graph[u][v];
                }
            }
        }

        // Print the MST
        System.out.println("Edge \tWeight");
        for (int i = 1; i < V; i++) {
            System.out.println(parent[i] + " - " + i + "\t" + graph[i][parent[i]]);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Take input for number of vertices and edges
        System.out.print("Enter the number of vertices: ");
        int V = sc.nextInt();
        int[][] graph = new int[V][V];

        System.out.print("Enter the number of edges: ");
        int E = sc.nextInt();

        System.out.println("Enter the edges in the format: vertex1 vertex2 weight");
        for (int i = 0; i < E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            int weight = sc.nextInt();
            graph[u][v] = weight;
            graph[v][u] = weight;  // Because the graph is undirected
        }

        // Call Prim's algorithm to find the MST
        primMST(graph, V);
    }
}
