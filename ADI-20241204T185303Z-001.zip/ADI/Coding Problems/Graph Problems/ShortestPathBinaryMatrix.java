import java.util.*;

public class ShortestPathBinaryMatrix {

    // Directions for 8-connected movement (Up, Down, Left, Right, and diagonals)
    private static final int[] rowDir = {-1, 1, 0, 0, -1, -1, 1, 1};
    private static final int[] colDir = {0, 0, -1, 1, -1, 1, -1, 1};

    // Check if the position is valid and open (0) and not visited
    private static boolean isValid(int x, int y, int n, int[][] grid, boolean[][] visited) {
        return x >= 0 && y >= 0 && x < n && y < n && grid[x][y] == 0 && !visited[x][y];
    }

    // Function to find the shortest path using BFS
    public static int shortestPathBinaryMatrix(int[][] grid) {
        int n = grid.length;

        // If start or end is blocked, return -1
        if (grid[0][0] == 1 || grid[n - 1][n - 1] == 1) {
            return -1;
        }

        // BFS queue: stores [row, col, distance]
        Queue<int[]> queue = new LinkedList<>();
        boolean[][] visited = new boolean[n][n];

        // Start from the top-left corner
        queue.offer(new int[]{0, 0, 1});
        visited[0][0] = true;

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int x = current[0], y = current[1], dist = current[2];

            // If we reach the bottom-right corner, return the distance
            if (x == n - 1 && y == n - 1) {
                return dist;
            }

            // Explore all 8 directions
            for (int i = 0; i < 8; i++) {
                int newX = x + rowDir[i];
                int newY = y + colDir[i];

                if (isValid(newX, newY, n, grid, visited)) {
                    visited[newX][newY] = true;
                    queue.offer(new int[]{newX, newY, dist + 1});
                }
            }
        }

        // If no path is found, return -1
        return -1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read matrix size (n x n)
        System.out.print("Enter the size of the matrix (n x n): ");
        int n = scanner.nextInt();

        // Read the binary matrix (grid)
        int[][] grid = new int[n][n];
        System.out.println("Enter the binary matrix (0 for open path, 1 for blocked path):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                grid[i][j] = scanner.nextInt();
            }
        }

        // Find and print the shortest path
        int result = shortestPathBinaryMatrix(grid);
        if (result == -1) {
            System.out.println("No path exists.");
        } else {
            System.out.println("The shortest path length is: " + result);
        }

        scanner.close();
    }
}
