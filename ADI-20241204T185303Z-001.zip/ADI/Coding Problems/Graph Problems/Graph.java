import java.util.Scanner;

public class Graph {
    // Number of vertices in the graph
    private int vertices;
    // Adjacency matrix to represent the graph
    private int[][] adjMatrix;

    // Constructor to initialize the graph with a given number of vertices
    public Graph(int vertices) {
        this.vertices = vertices;
        this.adjMatrix = new int[vertices][vertices];
    }

    // Method to add an edge to the graph (undirected graph)
    public void addEdge(int source, int destination) {
        adjMatrix[source][destination] = 1;
        adjMatrix[destination][source] = 1;  // For undirected graph
    }

    // Method to display the adjacency matrix
    public void displayGraph() {
        System.out.println("Adjacency Matrix:");
        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                System.out.print(adjMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Main method to take input and display the graph
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Take the number of vertices as input
        System.out.print("Enter the number of vertices in the graph: ");
        int n = sc.nextInt();
        
        // Create a graph object
        Graph graph = new Graph(n);
        
        // Take input for edges
        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();
        
        // Take each edge input and add to the graph
        for (int i = 0; i < edges; i++) {
            System.out.print("Enter source vertex of edge " + (i + 1) + ": ");
            int source = sc.nextInt();
            System.out.print("Enter destination vertex of edge " + (i + 1) + ": ");
            int destination = sc.nextInt();
            
            // Validate input (source and destination should be in the range [0, n-1])
            if (source >= 0 && source < n && destination >= 0 && destination < n) {
                graph.addEdge(source, destination);
            } else {
                System.out.println("Invalid vertices! Please enter vertices between 0 and " + (n - 1));
                i--;  // Decrement to re-enter the current edge
            }
        }
        
        // Display the graph as an adjacency matrix
        graph.displayGraph();
      }
}
