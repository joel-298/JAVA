import java.util.*;

public class GraphAdjList {

    // Using a Map to represent the adjacency list, where the key is the vertex and the value is a list of neighbors
    private Map<Integer, List<Integer>> adjList;

    // Constructor to initialize the adjacency list
    public GraphAdjList(int vertices) {
        adjList = new HashMap<>();
        // Initialize each vertex with an empty list of adjacent vertices
        for (int i = 0; i < vertices; i++) {
            adjList.put(i, new ArrayList<>());
        }
    }

    // Method to add an edge to the graph (undirected graph)
    public void addEdge(int source, int destination) {
        adjList.get(source).add(destination);
        adjList.get(destination).add(source); // For undirected graph
    }

    // Method to display the adjacency list
    public void displayGraph() {
        System.out.println("Adjacency List:");
        for (int vertex : adjList.keySet()) {
            System.out.print(vertex + ": ");
            for (int neighbor : adjList.get(vertex)) {
                System.out.print(neighbor + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input the number of vertices
        System.out.print("Enter the number of vertices: ");
        int n = sc.nextInt();

        // Create the graph object
        GraphAdjList graph = new GraphAdjList(n);

        // Input the number of edges
        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();

        // Input edges
        for (int i = 0; i < edges; i++) {
            System.out.print("Enter source vertex of edge " + (i + 1) + ": ");
            int source = sc.nextInt();
            System.out.print("Enter destination vertex of edge " + (i + 1) + ": ");
            int destination = sc.nextInt();

            // Add the edge to the graph
            graph.addEdge(source, destination);
        }

        // Display the adjacency list
        graph.displayGraph();

        sc.close();
    }
}
