import java.util.*;

public class SimpleGraphAdjList {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Input the number of vertices
        System.out.print("Enter the number of vertices: ");
        int n = sc.nextInt();
        
        // Create the adjacency list (array of lists)
        List<Integer>[] adjList = new ArrayList[n];
        for (int i = 0; i < n; i++) {
            adjList[i] = new ArrayList<>();
        }
        
        // Input the number of edges
        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();
        
        // Input edges and add them to the adjacency list
        for (int i = 0; i < edges; i++) {
            System.out.print("Enter source vertex of edge " + (i + 1) + ": ");
            int source = sc.nextInt();
            System.out.print("Enter destination vertex of edge " + (i + 1) + ": ");
            int destination = sc.nextInt();
            
            // Add the edge in both directions (undirected graph)
            adjList[source].add(destination);
            adjList[destination].add(source);
        }
        
        // Display the adjacency list
        System.out.println("Adjacency List:");
        for (int i = 0; i < n; i++) {
            System.out.print(i + ": ");
            for (int neighbor : adjList[i]) {
                System.out.print(neighbor + " ");
            }
            System.out.println();
        }
        
        sc.close();
    }
}
