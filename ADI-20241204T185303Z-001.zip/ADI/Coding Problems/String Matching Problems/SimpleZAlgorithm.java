import java.util.Scanner;

public class SimpleZAlgorithm {

    // Function to compute Z array
    public static int[] computeZArray(String str, String ptrn) {
        int n = str.length();
        int[] Z = new int[n];
        
        for (int i = (ptrn.length()+1); i < n; i++) {
            int j = 0;
            while (i + j < n && str.charAt(j) == str.charAt(i + j)) {
                j++;
            }
            Z[i] = j;
        }
	System.out.print("Z Array Values : ");
	for (int i=0;i<n;i++){
		System.out.print(Z[i]+" ");}
        
        return Z;
    }

    // Function to find the pattern in the text
    public static void searchPattern(String text, String pattern) {
        String concat = pattern + "$" + text; // Concatenate pattern, separator and text
        int[] Z = computeZArray(concat, pattern);
        
	 System.out.println();
        for (int i = 1; i < Z.length; i++) {
          if (Z[i] == pattern.length()) {
           System.out.println("Pattern found at index " + (i - pattern.length() - 1));
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get input from user
        System.out.print("Enter text: ");
        String text = scanner.nextLine();
        System.out.print("Enter pattern: ");
        String pattern = scanner.nextLine();

        // Search pattern in text
        searchPattern(text, pattern);
    }
}
