import java.util.Scanner;

public class KMP {
    
    // Function to preprocess the pattern and build the LPS (Longest Prefix Suffix) array
    public static int[] buildLPSArray(String pattern) {
        int[] lps = new int[pattern.length()];
        int length = 0; // Length of the previous longest prefix suffix
        int i = 1;
	
	for(int len : lps) {
	System.out.println("Value of lps["+len+"] :"+lps[len]);
	}
        
        // Build the LPS array
        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(length)) {
                length++;
                lps[i] = length;
                i++;
            } else {
                // mismatch after length matches
                if (length != 0) {
                    length = lps[length - 1]; // Use the previous prefix suffix value
                System.out.println("Value of lps[0] :"+ lps[0]);
		} else {
                    lps[i] = 0;
                    i++;
                }
            }
        }
        return lps;
    }
    
    // KMP algorithm to search for the pattern in the text
    public static void KMPSearch(String text, String pattern) {
        int[] lps = buildLPSArray(pattern); // Build the LPS array for the pattern
        int i = 0; // Index for text
        int j = 0; // Index for pattern
        
        while (i < text.length()) {
            if (pattern.charAt(j) == text.charAt(i)) {
                i++;
                j++;
            }
             // If the entire pattern is matched
            if (j == pattern.length()) {
                System.out.println("Pattern found at index " + (i - j));
                j = lps[j - 1]; // Use the LPS array to continue searching
            }
            // Mismatch after j matches
            else if (i < text.length() && pattern.charAt(j) != text.charAt(i)) {
                if (j != 0) {
                    j = lps[j - 1]; // Use the LPS array to skip the matched prefix
                } else {
                    i++;
                }
            }
        }
    }

    public static void main(String[] args) {
        // Take user input for the text and pattern
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the text: ");
        String text = scanner.nextLine();
        
        System.out.print("Enter the pattern: ");
        String pattern = scanner.nextLine();
        
        // Call the KMP search method to find the pattern in the text
        KMPSearch(text, pattern);
    }
}
