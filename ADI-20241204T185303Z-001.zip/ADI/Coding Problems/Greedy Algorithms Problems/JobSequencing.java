// Job Sequencing Problem

import java.util.Arrays;
import java.util.Comparator;

class Job {
    int id;
    int deadline;
    int profit;

    Job(int id, int deadline, int profit) {
        this.id = id;
        this.deadline = deadline;
        this.profit = profit;
    }
}

public class JobSequencing {

    public static void scheduleJobs(Job[] jobs) {
        // Sort jobs by profit in descending order
        Arrays.sort(jobs, new Comparator<Job>() {
            public int compare(Job a, Job b) {
                return b.profit - a.profit;
            }
        });

        int n = jobs.length;
        boolean[] slots = new boolean[n]; // To keep track of free time slots
        int[] result = new int[n]; // Store job IDs
        int countJobs = 0; // Count of jobs in the result
        int totalProfit = 0; // Total profit

        // Iterate through the jobs
        for (Job job : jobs) {
            // Find a free slot for this job
            for (int j = Math.min(n, job.deadline) - 1; j >= 0; j--) {
                if (!slots[j]) {
                    slots[j] = true; // Mark slot as filled
                    result[j] = job.id; // Assign job ID to the slot
                    countJobs++;
                    totalProfit += job.profit;
                    break;
                }
            }
        }

        // Output results
        System.out.println("Number of jobs done: " + countJobs);
        System.out.println("Total Profit: " + totalProfit);
        System.out.print("Jobs scheduled: ");
        for (int i = 0; i < n; i++) {
            if (slots[i]) {
                System.out.print(result[i] + " ");
            }
        }
    }

    public static void main(String[] args) {
        Job[] jobs = {
            new Job(1, 2, 100),
            new Job(2, 1, 19),
            new Job(3, 2, 27),
            new Job(4, 1, 25),
            new Job(5, 3, 15)
        };

        scheduleJobs(jobs);
    }
}
