// kth Largest using Priority Queue

import java.util.PriorityQueue;
import java.util.Scanner;

public class KLargestElement {
    public int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        
        // Fill the min heap with the first k elements
        for (int i = 0; i < k; i++) {
            minHeap.offer(nums[i]);
        }
        
        // Process the rest of the elements
        for (int i = k; i < nums.length; i++) {
            if (nums[i] > minHeap.peek()) {
                minHeap.poll();
                minHeap.offer(nums[i]);
            }
        }
        
        return minHeap.peek();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input the size of the array
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] nums = new int[n];

        // Input the array elements
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }

        // Input the value of k
        System.out.print("Enter the value of k: ");
        int k = scanner.nextInt();

        // Create an instance of Solution and find the k-th largest element
        KLargestElement solution = new KLargestElement();
        int kthLargest = solution.findKthLargest(nums, k);
        
        // Print the result
        System.out.println("The " + k + "-th largest element is: " + kthLargest);
        
        // Close the scanner
        scanner.close();
    }
}
