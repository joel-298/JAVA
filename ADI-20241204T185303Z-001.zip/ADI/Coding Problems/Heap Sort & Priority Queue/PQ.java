// Implement Priority Queue with linkedlist using inbuilt methods & class

import java.util.LinkedList;
import java.util.Scanner;

class PriorityQueueLinkedInbuild {
    private LinkedList<Node> list;

    // Node class to store data and priority
    private class Node {
        int data;
        int priority;

        Node(int data, int priority) {
            this.data = data;
            this.priority = priority;
        }
    }

    // Constructor
    public PriorityQueueLinkedInbuild() {
        list = new LinkedList<>();
    }

    // Method to insert an element with a given priority
    public void enqueue(int data, int priority) {
        Node newNode = new Node(data, priority);

        // Find the correct position to insert the new node
        int index = 0;
        for (Node node : list) {
            if (node.priority < priority) {
                break;
            }
            index++;
        }
        list.add(index, newNode);
    }

    // Method to remove and return the highest priority element
    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Priority Queue is empty");
        }
        return list.removeFirst().data; // Remove and return the first element (highest priority)
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return list.isEmpty();
    }

    // Method to peek at the highest priority element
    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Priority Queue is empty");
        }
        return list.getFirst().data; // Return the first element (highest priority) without removing it
    }

    // Method to print the elements of the queue
    public void printQueue() {
        for (Node node : list) {
            System.out.println("Data: " + node.data + ", Priority: " + node.priority);
        }
    }
}

public class PQ {
    public static void main(String[] args) {
        PriorityQueueLinkedInbuild pq = new PriorityQueueLinkedInbuild();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Peek");
            System.out.println("4. Print Queue");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter data: ");
                    int data = scanner.nextInt();
                    System.out.print("Enter priority: ");
                    int priority = scanner.nextInt();
                    pq.enqueue(data, priority);
                    System.out.println("Enqueued: " + data + " with priority " + priority);
                    break;
                case 2:
                    try {
                        System.out.println("Dequeued: " + pq.dequeue());
                    } catch (IllegalStateException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        System.out.println("Peek: " + pq.peek());
                    } catch (IllegalStateException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.out.println("Priority Queue:");
                    pq.printQueue();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}
