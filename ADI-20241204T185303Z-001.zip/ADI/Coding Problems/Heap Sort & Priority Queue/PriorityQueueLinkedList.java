// Implement Priority Queue with linkedlist

class Node {
    int data;
    int priority;
    Node next;

    Node(int data, int priority) {
        this.data = data;
        this.priority = priority;
        this.next = null;
    }
}

class PriorityQueueLinkedList {
    private Node head;

    // Method to insert an element with a given priority
    public void enqueue(int data, int priority) {
        Node newNode = new Node(data, priority);
        
        // If the queue is empty or the new node has a higher priority than the head
        if (head == null || head.priority < priority) {
            newNode.next = head;
            head = newNode;
        } else {
            // Traverse the list to find the appropriate position
            Node current = head;
            while (current.next != null && current.next.priority >= priority) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Method to remove and return the highest priority element
    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Priority Queue is empty");
        }
        int value = head.data;
        head = head.next; // Remove the head node
        return value;
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return head == null;
    }

    // Method to peek at the highest priority element
    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Priority Queue is empty");
        }
        return head.data;
    }
    
    // Method to print the elements of the queue
    public void printQueue() {
        Node current = head;
        while (current != null) {
            System.out.println("Data: " + current.data + ", Priority: " + current.priority);
            current = current.next;
        }
    }
}

public class Main {
    public static void main(String[] args) {
        PriorityQueueLinkedList pq = new PriorityQueueLinkedList();
        
        pq.enqueue(5, 2);
        pq.enqueue(10, 1);
        pq.enqueue(15, 3);
        
        System.out.println("Priority Queue:");
        pq.printQueue();
        
        System.out.println("Dequeued: " + pq.dequeue());
        
        System.out.println("Priority Queue after dequeue:");
        pq.printQueue();
        
        System.out.println("Peek: " + pq.peek());
    }
}
