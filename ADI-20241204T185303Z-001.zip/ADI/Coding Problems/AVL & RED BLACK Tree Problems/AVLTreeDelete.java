import java.util.Scanner;

class AVLTreeDelete {

    // Node class for AVL tree
    static class Node {
        int key, height;
        Node left, right;

        public Node(int key) {
            this.key = key;
            this.height = 1;
        }
    }

    private Node root;

    // Utility function to get height of the node
    private int height(Node node) {
        return node == null ? 0 : node.height;
    }

    // Update the height of the node
    private void updateHeight(Node node) {
        node.height = Math.max(height(node.left), height(node.right)) + 1;
    }

    // Get balance factor of the node
    private int getBalance(Node node) {
        return node == null ? 0 : height(node.left) - height(node.right);
    }

    // Right rotate utility
    private Node rightRotate(Node y) {
        Node x = y.left;
        Node T2 = x.right;
        x.right = y;
        y.left = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    // Left rotate utility
    private Node leftRotate(Node x) {
        Node y = x.right;
        Node T2 = y.left;
        y.left = x;
        x.right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    // Insert a key into the AVL tree
    public Node insert(Node node, int key) {
        if (node == null) {
            return new Node(key);
        }

        if (key < node.key) {
            node.left = insert(node.left, key);
        } else if (key > node.key) {
            node.right = insert(node.right, key);
        } else {
            return node;  // Duplicates not allowed
        }

        // Update height of the node
        updateHeight(node);

        // Get balance factor to check if the node is unbalanced
        int balance = getBalance(node);

        // If unbalanced, then perform rotations
        if (balance > 1 && key < node.left.key) {
            return rightRotate(node); // Left Left Case
        }
        if (balance < -1 && key > node.right.key) {
            return leftRotate(node); // Right Right Case
        }
        if (balance > 1 && key > node.left.key) {
            node.left = leftRotate(node.left);  // Left Right Case
            return rightRotate(node);
        }
        if (balance < -1 && key < node.right.key) {
            node.right = rightRotate(node.right);  // Right Left Case
            return leftRotate(node);
        }

        return node;
    }

    // Find the node with the minimum key value
    private Node minValueNode(Node node) {
        Node current = node;
        while (current.left != null) {
            current = current.left;
        }
        return current;
    }

    // Delete a node
    public Node delete(Node root, int key) {
        // STEP 1: Perform standard BST delete
        if (root == null) return root;

        if (key < root.key) {
            root.left = delete(root.left, key);
        } else if (key > root.key) {
            root.right = delete(root.right, key);
        } else {
            // Node with only one child or no child
            if (root.left == null || root.right == null) {
                Node temp = root.left != null ? root.left : root.right;
                root = temp;  // Copy the non-null child
            } else {
                // Node with two children: Get the inorder successor
                Node temp = minValueNode(root.right);
                root.key = temp.key;  // Copy the inorder successor's key
                root.right = delete(root.right, temp.key);  // Delete the inorder successor
            }
        }

        // If the tree has only one node, return it
        if (root == null) return root;

        // STEP 2: Update height of the current node
        updateHeight(root);

        // STEP 3: Get balance factor to check if the node became unbalanced
        int balance = getBalance(root);

        // If unbalanced, then perform rotations

        // Left Left Case
        if (balance > 1 && getBalance(root.left) >= 0) {
            return rightRotate(root);
        }

        // Right Right Case
        if (balance < -1 && getBalance(root.right) <= 0) {
            return leftRotate(root);
        }

        // Left Right Case
        if (balance > 1 && getBalance(root.left) < 0) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }

        // Right Left Case
        if (balance < -1 && getBalance(root.right) > 0) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }

        return root;
    }

    // Inorder traversal of the AVL tree
    public void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.key + " ");
            inorder(root.right);
        }
    }

    // Method to insert a key and maintain balance
    public void insert(int key) {
        root = insert(root, key);
    }

    // Method to delete a key and maintain balance
    public void delete(int key) {
        root = delete(root, key);
    }

    // Method to print inorder traversal
    public void inorderTraversal() {
        inorder(root);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AVLTree tree = new AVLTree();

        while (true) {
            System.out.println("\nAVL Tree Operations:");
            System.out.println("1. Insert a key");
            System.out.println("2. Delete a key");
            System.out.println("3. Inorder traversal");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter key to insert: ");
                    int key = scanner.nextInt();
                    tree.insert(key);
                    System.out.println(key + " inserted successfully.");
                    break;
                case 2:
                    System.out.print("Enter key to delete: ");
                    key = scanner.nextInt();
                    tree.delete(key);
                    System.out.println(key + " deleted successfully.");
                    break;
                case 3:
                    System.out.print("Inorder traversal: ");
                    tree.inorderTraversal();
                    System.out.println();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
