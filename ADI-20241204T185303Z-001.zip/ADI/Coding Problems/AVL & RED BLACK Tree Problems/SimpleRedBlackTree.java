import java.util.Scanner;

public class SimpleRedBlackTree {
    
    // Node structure
    class Node {
        int data;
        Node left, right, parent;
        boolean color;  // true for red, false for black
        
        public Node(int data) {
            this.data = data;
            left = right = parent = null;
            color = true; // New node is red by default
        }
    }
    
    private Node root;
    private Node TNULL; // Sentinel node for nil
    
    // Constructor
    public SimpleRedBlackTree() {
        TNULL = new Node(0); // Black sentinel node
        TNULL.color = false; // Black
        root = TNULL;
    }
    
    // Preorder Traversal
    public void preOrder() {
        preOrderHelper(root);
    }

    private void preOrderHelper(Node node) {
        if (node != TNULL) {
            System.out.print(node.data + " ");
            preOrderHelper(node.left);
            preOrderHelper(node.right);
        }
    }

    // Insertion
    public void insert(int key) {
        Node node = new Node(key);
        Node y = null;
        Node x = root;

        // Find the correct position for the new node
        while (x != TNULL) {
            y = x;
            if (node.data < x.data) {
                x = x.left;
            } else {
                x = x.right;
            }
        }

        node.parent = y;
        if (y == null) {
            root = node;  // Tree was empty, set root
        } else if (node.data < y.data) {
            y.left = node;
        } else {
            y.right = node;
        }

        node.left = TNULL;
        node.right = TNULL;
        node.color = true; // New node is red

        // Fix any violations of Red-Black Tree properties
        fixInsert(node);
    }

    private void fixInsert(Node node) {
        Node uncle;
        
        // While the parent is red, fix violations
        while (node.parent.color == true) {
            if (node.parent == node.parent.parent.right) {
                uncle = node.parent.parent.left;
                if (uncle.color == true) {
                    // Case 1: Uncle is red
                    uncle.color = false;
                    node.parent.color = false;
                    node.parent.parent.color = true;
                    node = node.parent.parent;
                } else {
                    if (node == node.parent.left) {
                        node = node.parent;
                        rightRotate(node);
                    }
                    node.parent.color = false;
                    node.parent.parent.color = true;
                    leftRotate(node.parent.parent);
                }
            } else {
                uncle = node.parent.parent.right;
                if (uncle.color == true) {
                    // Case 1: Uncle is red
                    uncle.color = false;
                    node.parent.color = false;
                    node.parent.parent.color = true;
                    node = node.parent.parent;
                } else {
                    if (node == node.parent.right) {
                        node = node.parent;
                        leftRotate(node);
                    }
                    node.parent.color = false;
                    node.parent.parent.color = true;
                    rightRotate(node.parent.parent);
                }
            }
            if (node == root) {
                break;
            }
        }
        root.color = false; // Root is always black
    }

    // Left rotate
    private void leftRotate(Node x) {
        Node y = x.right;
        x.right = y.left;
        if (y.left != TNULL) {
            y.left.parent = x;
        }
        y.parent = x.parent;
        if (x.parent == null) {
            root = y;
        } else if (x == x.parent.left) {
            x.parent.left = y;
        } else {
            x.parent.right = y;
        }
        y.left = x;
        x.parent = y;
    }

    // Right rotate
    private void rightRotate(Node x) {
        Node y = x.left;
        x.left = y.right;
        if (y.right != TNULL) {
            y.right.parent = x;
        }
        y.parent = x.parent;
        if (x.parent == null) {
            root = y;
        } else if (x == x.parent.right) {
            x.parent.right = y;
        } else {
            x.parent.left = y;
        }
        y.right = x;
        x.parent = y;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SimpleRedBlackTree tree = new SimpleRedBlackTree();

        System.out.print("Enter number of elements to insert: ");
        int n = scanner.nextInt();

        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            int value = scanner.nextInt();
            tree.insert(value);
        }

        System.out.print("Pre-order traversal of the Red-Black Tree: ");
        tree.preOrder();
    }
}
