import java.util.Scanner;

class AVLTreeRotateCount {

    // Node class for AVL tree
    static class Node {
        int key, height;
        Node left, right;

        public Node(int item) {
            key = item;
            height = 1;
        }
    }

    private Node root;
    private int rightRotations = 0;  // Counter for right rotations
    private int leftRotations = 0;   // Counter for left rotations

    // Utility function to get height of the node
    private int height(Node N) {
        if (N == null) return 0;
        return N.height;
    }

    // Utility function to get the balance factor of the node
    private int getBalance(Node N) {
        if (N == null) return 0;
        return height(N.left) - height(N.right);
    }

    // Right rotate utility function
    private Node rightRotate(Node y) {
        Node x = y.left;
        Node T2 = x.right;

        // Perform rotation
        x.right = y;
        y.left = T2;

        // Update heights
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        // Increment the right rotation counter
        rightRotations++;

        // Return the new root
        return x;
    }

    // Left rotate utility function
    private Node leftRotate(Node x) {
        Node y = x.right;
        Node T2 = y.left;

        // Perform rotation
        y.left = x;
        x.right = T2;

        // Update heights
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        // Increment the left rotation counter
        leftRotations++;

        // Return the new root
        return y;
    }

    // Insert a new key
    public Node insert(Node node, int key) {
        if (node == null) return new Node(key);

        // Perform normal BST insert
        if (key < node.key) {
            node.left = insert(node.left, key);
        } else if (key > node.key) {
            node.right = insert(node.right, key);
        } else {
            return node;  // Duplicate keys not allowed
        }

        // Update height of the current node
        node.height = Math.max(height(node.left), height(node.right)) + 1;

        // Get the balance factor
        int balance = getBalance(node);

        // Perform rotations if the node becomes unbalanced
        if (balance > 1 && key < node.left.key) {
            return rightRotate(node);  // Left Left Case
        }

        if (balance < -1 && key > node.right.key) {
            return leftRotate(node);  // Right Right Case
        }

        if (balance > 1 && key > node.left.key) {
            node.left = leftRotate(node.left);  // Left Right Case
            return rightRotate(node);
        }

        if (balance < -1 && key < node.right.key) {
            node.right = rightRotate(node.right);  // Right Left Case
            return leftRotate(node);
        }

        return node;
    }

    // Helper function to do an inorder traversal of the tree
    public void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.key + " ");
            inorder(root.right);
        }
    }

    // Method to insert a key and maintain balance
    public void insert(int key) {
        root = insert(root, key);
    }

    // Method to print inorder traversal
    public void inorderTraversal() {
        inorder(root);
    }

    // Method to display rotation counts
    public void displayRotationCounts() {
        System.out.println("Left Rotations: " + leftRotations);
        System.out.println("Right Rotations: " + rightRotations);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AVLTreeRotateCount tree = new AVLTreeRotateCount();
        
        while (true) {
            System.out.println("AVL Tree Operations:");
            System.out.println("1. Insert a key");
            System.out.println("2. Inorder traversal");
            System.out.println("3. Display rotation counts");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter key to insert: ");
                    int key = scanner.nextInt();
                    tree.insert(key);
                    System.out.println(key + " inserted successfully.");
                    break;
                case 2:
                    System.out.println("Inorder traversal of AVL Tree: ");
                    tree.inorderTraversal();
                    System.out.println();  // for newline
                    break;
                case 3:
                    tree.displayRotationCounts();  // Display left and right rotation counts
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
