// N Queen Problem

import java.util.Scanner;

public class NQueens {

    private int[] board;
    private int solutionsCount;

    public NQueens(int n) {
        board = new int[n];
        solutionsCount = 0;
    }

    public void solveNQueens() {
        placeQueen(0);
        System.out.println("Total solutions: " + solutionsCount);
    }

    private void placeQueen(int row) {
        int n = board.length;
        if (row == n) {
            printSolution();
            solutionsCount++;
            return;
        }

        for (int col = 0; col < n; col++) {
            if (isSafe(row, col)) {
                board[row] = col; // Place queen
                placeQueen(row + 1); // Move to the next row
                // No need to remove queen, as we're overwriting
            }
        }
    }

    private boolean isSafe(int row, int col) {
        for (int i = 0; i < row; i++) {
            // Check column and diagonals
            if (board[i] == col || 
                board[i] - i == col - row || 
                board[i] + i == col + row) {
                return false;
            }
        }
        return true;
    }

    private void printSolution() {
        int n = board.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (board[i] == j) {
                    System.out.print("Q ");
                } else {
                    System.out.print(". ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value of n (number of queens): ");
        int n = scanner.nextInt();

        NQueens nQueens = new NQueens(n);
        nQueens.solveNQueens();

        scanner.close();
    }
}
