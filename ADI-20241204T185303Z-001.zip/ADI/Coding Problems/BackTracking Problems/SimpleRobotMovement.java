// Robot Movement using Backtracking

import java.util.Scanner;

public class SimpleRobotMovement {
    static boolean foundPath = false;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the grid size (N x N): ");
        int n = scanner.nextInt();
        int[][] grid = new int[n][n];

        System.out.println("Enter the grid (0 for free cell, 1 for obstacle):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                grid[i][j] = scanner.nextInt();
            }
        }

        System.out.print("Enter start row and column: ");
        int startRow = scanner.nextInt();
        int startCol = scanner.nextInt();
        System.out.print("Enter destination row and column: ");
        int destRow = scanner.nextInt();
        int destCol = scanner.nextInt();

        boolean[][] visited = new boolean[n][n];
        findPath(grid, startRow, startCol, destRow, destCol, visited);

        if (foundPath) {
            System.out.println("Path found!");
        } else {
            System.out.println("No path found.");
        }

        scanner.close();
    }

    static void findPath(int[][] grid, int row, int col, int destRow, int destCol, boolean[][] visited) {
        if (row < 0 || col < 0 || row >= grid.length || col >= grid.length ||
            grid[row][col] == 1 || visited[row][col]) {
            return;
        }

        if (row == destRow && col == destCol) {
            foundPath = true;
            return;
        }

        visited[row][col] = true;

        // Move in all four directions
        findPath(grid, row - 1, col, destRow, destCol, visited); // Up
        findPath(grid, row + 1, col, destRow, destCol, visited); // Down
        findPath(grid, row, col - 1, destRow, destCol, visited); // Left
        findPath(grid, row, col + 1, destRow, destCol, visited); // Right

        visited[row][col] = false; // Backtrack
    }
}
