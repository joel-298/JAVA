// Print n bit Strings of n

import java.util.Scanner;

public class NBitStrings {
    private static int count = 0; // Variable to count the total number of strings

    // Helper function to perform backtracking
    private static void generateBitStrings(int n, String current) {
        if (current.length() == n) {
            System.out.println(current);
            count++; // Increment count for each generated string
            return;
        }

        // Append '0' and recurse
        generateBitStrings(n, current + '0');

        // Append '1' and recurse
        generateBitStrings(n, current + '1');
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();

        generateBitStrings(n, "");
        
        System.out.println("Total number of " + n + "-bit strings: " + count);
    }
}
