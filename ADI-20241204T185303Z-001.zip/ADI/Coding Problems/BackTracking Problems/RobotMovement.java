// Robot Movement Program

import java.util.Scanner;

class RobotMovement {

    // Function to find final position of robot after the complete movement
    static void finalPosition(String move) {
        int l = move.length();
        int countUp = 0, countDown = 0;
        int countLeft = 0, countRight = 0;

        // Traverse the instruction string 'move'
        for (int i = 0; i < l; i++) {
            // Increment respective counters based on movement
            if (move.charAt(i) == 'U')
                countUp++;
            else if (move.charAt(i) == 'D')
                countDown++;
            else if (move.charAt(i) == 'L')
                countLeft++;
            else if (move.charAt(i) == 'R')
                countRight++;
        }

        // Required final position of robot
        System.out.println("Final Position: ("
                + (countRight - countLeft) + ", "
                + (countUp - countDown) + ")");
    }

    // Driver code
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter movement commands (U, D, L, R): ");
        String move = scanner.nextLine();

        // Call the function to calculate final position
        finalPosition(move);

        // Close the scanner
        scanner.close();
    }
}

