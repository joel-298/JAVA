// Rat in Maze Problem

import java.util.Scanner;

public class RatInMaze {
    private static final int N = 4; // Size of the maze

    public static void main(String[] args) {
        int[][] maze = new int[N][N];
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the maze (0 for open cell, 1 for blocked cell):");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                maze[i][j] = scanner.nextInt();
            }
        }

        int[][] solution = new int[N][N];
        if (solveMaze(maze, 0, 0, solution)) {
            System.out.println("Path to the exit:");
            printSolution(solution);
        } else {
            System.out.println("No path exists.");
        }

        scanner.close();
    }

    private static boolean solveMaze(int[][] maze, int x, int y, int[][] solution) {
        // Base case: If (x, y) is the bottom-right corner
        if (x == N - 1 && y == N - 1) {
            solution[x][y] = 1;
            return true;
        }

        // Check if current cell is valid
        if (isSafe(maze, x, y)) {
            solution[x][y] = 1; // Mark the cell in the solution path

            // Move forward in x direction
            if (solveMaze(maze, x + 1, y, solution)) {
                return true;
            }

            // If moving in x direction doesn't lead to a solution, move down in y direction
            if (solveMaze(maze, x, y + 1, solution)) {
                return true;
            }

            // If neither direction worked, backtrack
            solution[x][y] = 0; // Unmark this cell
            return false;
        }

        return false;
    }

    private static boolean isSafe(int[][] maze, int x, int y) {
        // Check if x and y are within bounds and the cell is not blocked
        return (x >= 0 && x < N && y >= 0 && y < N && maze[x][y] == 0);
    }

    private static void printSolution(int[][] solution) {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                System.out.print(solution[i][j] + " ");
            }
            System.out.println();
        }
    }
}
