import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RatInMazeAllPaths {
    private static final int N = 4; // Size of the maze

    public static void main(String[] args) {
        int[][] maze = new int[N][N];
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the maze (0 for open cell, 1 for blocked cell):");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                maze[i][j] = scanner.nextInt();
            }
        }

        List<List<int[][]>> allSolutions = new ArrayList<>();
        int[][] solution = new int[N][N];

        findAllPaths(maze, 0, 0, solution, allSolutions);

        if (allSolutions.isEmpty()) {
            System.out.println("No path exists.");
        } else {
            System.out.println("All feasible paths:");
            for (List<int[][]> sol : allSolutions) {
                printSolution(sol);
                System.out.println();
            }
        }

        scanner.close();
    }

    private static void findAllPaths(int[][] maze, int x, int y, int[][] solution, List<List<int[][]>> allSolutions) {
        // Base case: If (x, y) is the bottom-right corner
        if (x == N - 1 && y == N - 1) {
            solution[x][y] = 1;
            addSolution(solution, allSolutions);
            solution[x][y] = 0; // Backtrack to find other solutions
            return;
        }

        // Check if current cell is valid
        if (isSafe(maze, x, y)) {
            solution[x][y] = 1; // Mark the cell in the solution path

            // Move down
            findAllPaths(maze, x + 1, y, solution, allSolutions);
            // Move right
            findAllPaths(maze, x, y + 1, solution, allSolutions);
            // Move up
            findAllPaths(maze, x - 1, y, solution, allSolutions);
            // Move left
            findAllPaths(maze, x, y - 1, solution, allSolutions);

            // Backtrack
            solution[x][y] = 0; // Unmark this cell
        }
    }

    private static boolean isSafe(int[][] maze, int x, int y) {
        return (x >= 0 && x < N && y >= 0 && y < N && maze[x][y] == 0);
    }

    private static void addSolution(int[][] solution, List<List<int[][]>> allSolutions) {
        int[][] path = new int[N][N];
        for (int i = 0; i < N; i++) {
            System.arraycopy(solution[i], 0, path[i], 0, N);
        }
        allSolutions.add(new ArrayList<>(List.of(path)));
    }

    private static void printSolution(List<int[][]> solutions) {
        for (int[][] solution : solutions) {
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    System.out.print(solution[i][j] + " ");
                }
                System.out.println();
            }
        }
    }
}
