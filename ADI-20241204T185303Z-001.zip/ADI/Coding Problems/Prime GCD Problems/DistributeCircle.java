// Distribute in Circle Problem

import java.util.Scanner;

public class DistributeCircle {

    public static int solve(int A, int B, int C) {
        int n = (A + C - 1) % B;

        if (n == 0) {
            return B;
        }
        return n;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get user input
        System.out.print("Enter values for A, B, and C: ");
        int A = scanner.nextInt();
        int B = scanner.nextInt();
        int C = scanner.nextInt();

        // Call the solve function
        int result = solve(A, B, C);

        // Display the result
        System.out.println("Result: " + result);

        // Close the scanner
        scanner.close();
    }
}
