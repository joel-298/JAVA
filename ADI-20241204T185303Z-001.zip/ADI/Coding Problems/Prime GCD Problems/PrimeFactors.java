import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

class Solution {
    public int distinctPrimeFactors(int[] nums) {
        Set<Integer> primeFactors = new HashSet<>();
	int count=0;
        for (int num : nums) {
            // Factorize num into its prime factors
            int i = 2;
            while (num > 1) {
                if (num % i == 0) {
		    System.out.println("Prime Factor is :"+i);
                    primeFactors.add(i);
                    num /= i;
		    count++;
               	 } 
		  else {
                	    i++;
               	 }
            } 
        }System.out.println("Total Prime Factor :"+count);
        return primeFactors.size();
    }
}

public class PrimeFactors {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();
        int[] nums = new int[n];
        
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }
        
        Solution solution = new Solution();
        int result = solution.distinctPrimeFactors(nums);
        
        System.out.println("The number of distinct prime factors is: " + result);
        
        scanner.close();
    }
}


