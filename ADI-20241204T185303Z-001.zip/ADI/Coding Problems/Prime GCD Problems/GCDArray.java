// GCD of Array 

import java.util.Arrays;
import java.util.Scanner;

class GCDArray {
    public int findGCD(int[] nums) {
        Arrays.sort(nums);
        int GCD = 1;
        for (int i = 1; i <= nums[0]; i++) {
            if (nums[0] % i == 0 && nums[nums.length - 1] % i == 0) {
                GCD = i;
            }
        }
        return GCD;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();
        
        int[] nums = new int[n];
        System.out.println("Enter " + n + " positive integers:");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }

        GCDArray solution = new GCDArray();
        int result = solution.findGCD(nums);
        System.out.println("GCD of the array: " + result);
        
        scanner.close();
    }
}


