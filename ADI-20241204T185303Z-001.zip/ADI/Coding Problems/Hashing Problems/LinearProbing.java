// Hash Table LinearProbe Problem

import java.util.Scanner;

public class LinearProbing {
    private String[] keys;
    private String[] values;
    private int size;
    private int capacity;

    public LinearProbing(int capacity) {
        keys = new String[capacity];
        values = new String[capacity];
        this.size = 0;
        this.capacity = capacity;
    }

    public void makeEmpty() {
        size = 0;
        keys = new String[capacity];
        values = new String[capacity];
    }

    public int getSize() {
        return size;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isFull() {
        return size == capacity;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private int getHash(String key) {
        return Math.abs(key.hashCode() % capacity);
    }

    public void insert(String key, String value) {
        if (isFull()) {
            System.out.println("No room to insert");
            return;
        }
        int temp = getHash(key);
        int i = temp;
        do {
            if (keys[i] == null || keys[i].equals("DELETED")) {
                keys[i] = key;
                values[i] = value;
                size++;
                return;
            }
            if (keys[i].equals(key)) {
                values[i] = value;
                return;
            }
            i = (i + 1) % capacity;
        } while (i != temp);
    }

    public String get(String key) {
        int i = getHash(key);
        while (keys[i] != null) {
            if (keys[i].equals(key)) {
                return values[i];
            }
            i = (i + 1) % capacity;
        }
        return "not found";
    }

    public boolean contains(String key) {
        return get(key) != null && !get(key).equals("not found");
    }

    public void remove(String key) {
        if (!contains(key)) {
            return;
        }
        int i = getHash(key);
        while (!keys[i].equals(key)) {
            i = (i + 1) % capacity;
        }
        keys[i] = values[i] = "DELETED";
        size--;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the capacity of the hash table: ");
        int capacity = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        LinearProbing hashTable = new LinearProbing(capacity);

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Insert");
            System.out.println("2. Get");
            System.out.println("3. Remove");
            System.out.println("4. Check if contains");
            System.out.println("5. Display size and capacity");
            System.out.println("6. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (choice) {
                case 1:
                    System.out.print("Enter key: ");
                    String insertKey = scanner.nextLine();
                    System.out.print("Enter value: ");
                    String insertValue = scanner.nextLine();
                    hashTable.insert(insertKey, insertValue);
                    break;
                case 2:
                    System.out.print("Enter key to get value: ");
                    String getKey = scanner.nextLine();
                    System.out.println("Value: " + hashTable.get(getKey));
                    break;
                case 3:
                    System.out.print("Enter key to remove: ");
                    String removeKey = scanner.nextLine();
                    hashTable.remove(removeKey);
                    System.out.println("Removed key: " + removeKey);
                    break;
                case 4:
                    System.out.print("Enter key to check existence: ");
                    String containsKey = scanner.nextLine();
                    System.out.println("Contains " + containsKey + ": " + hashTable.contains(containsKey));
                    break;
                case 5:
                    System.out.println("Size: " + hashTable.getSize() + ", Capacity: " + hashTable.getCapacity());
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
