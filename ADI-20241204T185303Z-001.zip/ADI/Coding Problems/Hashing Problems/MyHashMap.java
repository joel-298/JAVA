// 2 Sum using LinkedHashMap

import java.util.Scanner;

class ListNode {
    int key, val;
    ListNode next;

    public ListNode(int key, int val, ListNode next) {
        this.key = key;
        this.val = val;
        this.next = next;
    }
}

class MyHashMap {
    static final int size = 19997;
    static final int mult = 12582917;
    ListNode[] data;

    public MyHashMap() {
        this.data = new ListNode[size];
    }

    private int hash(int key) {
        return (int)((long)key * mult % size);
    }

    public void put(int key, int val) {
        remove(key);
        int h = hash(key);
        ListNode node = new ListNode(key, val, data[h]);
        data[h] = node;
    }

    public int get(int key) {
        int h = hash(key);
        ListNode node = data[h];
        for (; node != null; node = node.next) {
            if (node.key == key) return node.val;
        }
        return -1; // Return -1 if the key does not exist
    }

    public void remove(int key) {
        int h = hash(key);
        ListNode node = data[h];
        if (node == null) return;
        if (node.key == key) {
            data[h] = node.next;
        } else {
            while (node.next != null) {
                if (node.next.key == key) {
                    node.next = node.next.next;
                    return;
                }
                node = node.next;
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        MyHashMap myHashMap = new MyHashMap();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Choose an operation: (1) put (2) get (3) remove (4) exit");
            int operation = scanner.nextInt();
            switch (operation) {
                case 1: // put
                    System.out.print("Enter key: ");
                    int putKey = scanner.nextInt();
                    System.out.print("Enter value: ");
                    int putValue = scanner.nextInt();
                    myHashMap.put(putKey, putValue);
                    System.out.println("Added (" + putKey + ", " + putValue + ")");
                    break;
                case 2: // get
                    System.out.print("Enter key: ");
                    int getKey = scanner.nextInt();
                    int value = myHashMap.get(getKey);
                    if (value == -1) {
                        System.out.println("Key not found");
                    } else {
                        System.out.println("Value for key " + getKey + ": " + value);
                    }
                    break;
                case 3: // remove
                    System.out.print("Enter key: ");
                    int removeKey = scanner.nextInt();
                    myHashMap.remove(removeKey);
                    System.out.println("Removed key " + removeKey);
                    break;
                case 4: // exit
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid operation. Please try again.");
            }
        }
    }
}
